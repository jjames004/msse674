

package com.bakeryorder.model.business.managerTest;

import org.junit.jupiter.api.Test;
import junit.framework.TestCase;

import com.bakeryorder.model.business.manager.AdminManager;
import com.bakeryorder.model.business.manager.ManagerSuperType;
import com.bakeryorder.model.business.manager.AdminManager;
import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.Admin;
import com.bakeryorder.model.services.exception.AdminException;
import com.bakeryorder.model.services.factory.SvcFactory;

class AdminManagerTest extends TestCase {
	
	private SvcFactory svcFactory;
	private Admin Admin;
	private AdminManager userMgr;
	private int id; 
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		Admin admin1 = new Admin(100, "Joe Dirt", "joedirt@gmail.com", "password"); 
		
		id = Admin.getId();

	}
		

	@Test
	void testcreateAdmin() 
			throws ServiceLoadException, AdminException {
		
			try {
				assertTrue(ManagerSuperType.class.isAssignableFrom(AdminManager.class));
		  	    assertTrue(AdminManager.createAdmin(Admin));
		        System.out.println("testCreateAdmin PASSED");	  	    
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				System.out.println("Test complete!");
			}
	}
		
	@Test
	void testGetAdmin()
			throws ServiceLoadException, AdminException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(AdminManager.class));
	  	    System.out.println(AdminManager.getAdmin(id));
	        System.out.println("testGetAdmin PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("Test complete!");
		}
	}
}
