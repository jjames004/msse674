package com.bakeryorder.model.business.managerTest;

import org.junit.jupiter.api.Test;
import junit.framework.TestCase;

import com.bakeryorder.model.business.manager.CakeManager;
import com.bakeryorder.model.business.manager.ManagerSuperType;
import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.Cake;
import com.bakeryorder.model.services.exception.CakeException;
import com.bakeryorder.model.services.factory.SvcFactory;

class CakeManagerTest extends TestCase {
	
	private SvcFactory svcFactory;
	private Cake cake;
	private CakeManager cakeMgr;
	private int id; 
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		Cake cake1 = new Cake(100, "cake@gmail.com", "chocolate", "the best cake name"); 
		
		id = cake1.getId();

	}
		

	@Test
	void testCreateCake() 
			throws ServiceLoadException, CakeException {
		
			try {
				assertTrue(ManagerSuperType.class.isAssignableFrom(CakeManager.class));
		  	    assertTrue(CakeManager.createCake(cake));
		        System.out.println("testCreateCake PASSED");	  	    
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				System.out.println("Test complete!");
			}
	}
		
	@Test
	void testGetUser()
			throws ServiceLoadException, CakeException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(CakeManager.class));
	  	    System.out.println(CakeManager.getCake(id));
	        System.out.println("testGetCake PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("Test complete!");
		}
	}
}