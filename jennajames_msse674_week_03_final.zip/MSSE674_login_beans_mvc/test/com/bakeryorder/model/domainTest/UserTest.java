package com.bakeryorder.model.domainTest;

import static org.junit.Assert.*;
import org.junit.Test;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bakeryorder.model.domain.User;


class UserTest {

	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(UserTest.class.getName());
	
	User user1 = new User(100, "Joe", "Dirt", "joedirt@gmail.com"); 
	
    User user2 = new User(200, "Peggy", "Hill", "peggyhill@gmail.com");

    @Test
	void testEqualsCustomer() {
		
		// calling the override equals method
		LOGGER.info("Test equal method override: " + user1.equals(user2));
		
		if(user1.equals(user2)) {
			LOGGER.error("The customer objects are equal!");
		} else {
			LOGGER.info("The customer objects are NOT equal!");
		}
	}
    

    @Test
	void testValidateCustomer() {
    	assertNotNull(user2.getId());
    	assertNotNull(user2.getFullname());
    	assertNotNull(user2.getPassword());
    	assertNotNull(user2.getEmail());
    }

}
