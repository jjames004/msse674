package com.bakeryorder.model.domain;

public class Cake {
	
	private int id;
	private String cakename;
	private String email;
	private String flavor;
	
	public Cake() {}
	

	
	public Cake(String email, String flavor, String cakename) {
        super();
        this.cakename = cakename;
        this.email = email;
        this.flavor = flavor;
    }
	
	 public Cake(int id, String email, String flavor, String cakename) {
	        super();
	        this.id = id;
	        this.cakename = cakename;
	        this.email = email;
	        this.flavor = flavor;

	    }
	 
	 


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}



	public String getFlavor() {
		return flavor;
	}

	public String getCakename() {
		return cakename;
	}



	public void setCakename(String cakename) {
		this.cakename = cakename;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}



	

}
