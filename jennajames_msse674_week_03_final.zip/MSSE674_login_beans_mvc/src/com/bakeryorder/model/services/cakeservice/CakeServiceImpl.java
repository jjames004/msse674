package com.bakeryorder.model.services.cakeservice;

import java.util.ArrayList;

import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.Cake;
import com.bakeryorder.model.services.exception.CakeException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CakeServiceImpl implements ICakeService {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CakeServiceImpl.class.getName());

	@Override
	public boolean createCake(Composite composite) throws CakeException {
		LOGGER.info("CakeServiceImpl::createCake().");
		boolean isSuccess = false;
		
		try {
			Cake create = composite.getCake();
			isSuccess = true;
		} catch (Exception ex){
			throw new CakeException("ERROR:  There was a problem with the CakeService.", ex);
		} 
		return isSuccess;
	}
	
	@Override
	public boolean readCake(Composite composite) throws CakeException {
		LOGGER.info("CakeServiceImpl::readCake().");
		boolean isSuccess = false;
		
		try {
			Cake read = composite.getCake();
			isSuccess = true;
		} catch (Exception ex){
			throw new CakeException("ERROR:  There was a problem with the CakeService.", ex);
		} 
		return isSuccess;
	}

	@Override
	public boolean updateCake(Composite composite) throws CakeException {
		LOGGER.info("INFO: CakeServiceImpl::updateCake().");
		boolean isSuccess = false;
		
		try {
			Cake update = composite.getCake();
			isSuccess = true;
		} catch (Exception ex){
			throw new CakeException("ERROR:  There was a problem with the CakeService.", ex);
		} 
		return isSuccess;
	}

	

	@Override
	public boolean deleteCake(Composite composite) throws CakeException {
		LOGGER.info("INFO: CakeServiceImpl::deleteCake().");
		boolean isSuccess = false;
		
		try {
			Cake delete = composite.getCake();
			isSuccess = true;
		} catch (Exception ex){
			throw new CakeException("ERROR:  There was a problem with the CakeService.", ex);
		} 
		return isSuccess;
	}


}
