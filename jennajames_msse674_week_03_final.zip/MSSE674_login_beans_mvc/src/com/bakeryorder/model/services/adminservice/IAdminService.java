package com.bakeryorder.model.services.adminservice;

import com.bakeryorder.model.domain.AdminComposite;
import com.bakeryorder.model.services.IService;
import com.bakeryorder.model.services.exception.AdminException;

public interface IAdminService extends IService {
	
	public final String NAME = "IAdminService";
	
	// list the methods available through the specific interface
	// each method accepts an instance of the composite class
	
	public boolean createUser(AdminComposite composite) throws AdminException;
	public boolean readUser(AdminComposite composite) throws AdminException;
	public boolean updateUser(AdminComposite composite) throws AdminException;
	public boolean deleteUser(AdminComposite composite) throws AdminException;

}
