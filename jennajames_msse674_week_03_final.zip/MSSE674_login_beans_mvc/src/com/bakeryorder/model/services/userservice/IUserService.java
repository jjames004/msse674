package com.bakeryorder.model.services.userservice;

import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.services.IService;
import com.bakeryorder.model.services.exception.UserException;

public interface IUserService extends IService {
	
	public final String NAME = "ICakeService";
	
	// list the methods available through the specific interface
	// each method accepts an instance of the composite class
	
	public boolean createUser(Composite composite) throws UserException;
	public boolean readUser(Composite composite) throws UserException;
	public boolean updateUser(Composite composite) throws UserException;
	public boolean deleteUser(Composite composite) throws UserException;

}
