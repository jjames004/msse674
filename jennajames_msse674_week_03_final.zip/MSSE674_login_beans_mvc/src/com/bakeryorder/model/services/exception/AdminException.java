package com.bakeryorder.model.services.exception;

public class AdminException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	public AdminException(final String inMessage)
    {
        super(inMessage);
    }

	
	public AdminException(final String inMessage, final Throwable inNestedException)
    {
        super(inMessage, inNestedException);
    }


}
