package com.bakeryorder.presentation.controller;

import java.io.*;
import java.sql.SQLException;
 
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.bakeryorder.model.domain.User;
import com.bakeryorder.model.integration.jdbc.UserDAO;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/userlogin")
public class UserLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    public UserLoginServlet() {
        super();
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
         
        UserDAO userDao = new UserDAO();
         
        try {
            User user = userDao.checkLogin(email, password);
            String destPage = "userlogin.jsp";
             
            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("user", user); 
                /* the scope is changed here with req.setAttribute(), sessionsetAttribute(), contextsetAttribute() 
                 for request, session and application scopes respectively */
                // setAttribute(String key, Object obj);
                // key is the "lookup" name
                // the object is the item stored or retrieved within a particular scope
                // implicit casting with the setAttrbute method
                destPage = "userhome.jsp";
            } else {
                String message = "Invalid email/password";
                request.setAttribute("message", message);
                // the doPost() method handles the request to login from the server-side. 
				// It calls the checkLogin() method of the UserDAO class to verify email and password against the database
            }
            
            // sends the request to the appropriate view (or JSP) file
            // connected to the destination page defined above
            RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
            dispatcher.forward(request, response);
             
        } catch (SQLException | ClassNotFoundException ex) {
            throw new ServletException(ex);
        }
    }
}
