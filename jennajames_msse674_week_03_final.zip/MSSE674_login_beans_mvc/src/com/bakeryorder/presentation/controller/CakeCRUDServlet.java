package com.bakeryorder.presentation.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bakeryorder.model.integration.jdbc.CakeDAO;
import com.bakeryorder.model.domain.Cake;

/**
 * ControllerServlet.java
 * This servlet acts as a page controller for the application, handling all
 * requests from the user.
 */

//@WebServlet("/")
public class CakeCRUDServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CakeDAO cakeDAO;
	
	public void init() {
		cakeDAO = new CakeDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/newCake":
				showNewFormCake(request, response);
				break;
			case "/insertCake":
				insertCake(request, response);
				break;
			case "/deleteCake":
				deleteCake(request, response);
				break;
			case "/editCake":
				showEditFormCake(request, response);
				break;
			case "/updateCake":
				updateCake(request, response);
				break;
			default:
				listCake(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listCake(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Cake> listCake = cakeDAO.selectAllCakes();
		request.setAttribute("listCake", listCake);
		RequestDispatcher dispatcher = request.getRequestDispatcher("cake-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewFormCake(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("cake-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditFormCake(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Cake existingCake = cakeDAO.selectCake(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("cake-form.jsp");
		request.setAttribute("cake", existingCake);
		dispatcher.forward(request, response);

	}

	private void insertCake(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String email = request.getParameter("email");
		String flavor = request.getParameter("flavor");
		String cakename = request.getParameter("cakename");
		Cake newCake = new Cake(email, flavor, cakename);
		cakeDAO.insertCake(newCake);
		response.sendRedirect("listCake");
	}

	private void updateCake(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		
		String email = request.getParameter("email");
		String flavor = request.getParameter("flavor");
		String cakename = request.getParameter("cakename");

		Cake cake = new Cake(id, email, flavor, cakename);
		cakeDAO.updateCake(cake);
		response.sendRedirect("listCake");
	}

	private void deleteCake(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		cakeDAO.deleteCake(id);
		response.sendRedirect("listCake");

	}

}
