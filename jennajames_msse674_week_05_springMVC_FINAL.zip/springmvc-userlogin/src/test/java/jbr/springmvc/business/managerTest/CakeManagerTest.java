
/* JUnit 4 */


package jbr.springmvc.business.managerTest;

import junit.framework.TestCase;

import jbr.springmvc.business.manager.CakeManager;
import jbr.springmvc.business.manager.ManagerSuperType;
import jbr.springmvc.business.exception.ServiceLoadException;
import jbr.springmvc.model.Cake;
import jbr.springmvc.services.exception.CakeException;
import jbr.springmvc.service.factory.SvcFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

public class CakeManagerTest extends TestCase {
	
	
	public CakeManagerTest( String constructor )
	{ super( constructor );
	}
	
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CakeManagerTest.class.getName());
	
	private SvcFactory svcFactory;
	private Cake cake;
	private CakeManager cakeMgr;
	private int id; 
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		Cake cake1 = new Cake("flavor", 123, 4); 
		
		id = cake1.getId();

	}
		

	@Test
	public void testCreateCake() 
			throws ServiceLoadException, CakeException {
		
			try {
				assertTrue(ManagerSuperType.class.isAssignableFrom(CakeManager.class));
		  	    assertTrue(CakeManager.createCake(cake));
		        LOGGER.info("testCreateCake PASSED");	  	    
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.error("EXECPTION");
			} finally {
				LOGGER.info("Test complete!");
			}
	}
		
	@Test
	public void testGetCake()
			throws ServiceLoadException, CakeException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(CakeManager.class));
			LOGGER.info(CakeManager.getCake(id));
			LOGGER.info("testGetCake PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("EXECPTION");
		} finally {
			LOGGER.info("Test complete!");
		}
	}
}