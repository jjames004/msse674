
/* JUnit 4 */


package jbr.springmvc.business.managerTest;

import junit.framework.TestCase;

import jbr.springmvc.business.manager.CustomerManager;
import jbr.springmvc.business.manager.ManagerSuperType;
import jbr.springmvc.business.exception.ServiceLoadException;
import jbr.springmvc.model.Customer;
import jbr.springmvc.services.exception.CustomerException;
import jbr.springmvc.service.factory.SvcFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

public class CustomerManagerTest extends TestCase {
	
	
	public CustomerManagerTest( String constructor )
	{ super( constructor );
	}
	
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CustomerManagerTest.class.getName());
	
	private SvcFactory svcFactory;
	private Customer customer;
	private CustomerManager customerMgr;
	private int id; 
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		Customer customer1 = new Customer("firstname", "lastname", "email"); 
		
		id = customer1.getId();

	}
		

	@Test
	public void testCreateCustomer() 
			throws ServiceLoadException, CustomerException {
		
			try {
				assertTrue(ManagerSuperType.class.isAssignableFrom(CustomerManager.class));
		  	    assertTrue(CustomerManager.createCustomer(customer));
		        LOGGER.info("testCreateCustomer PASSED");	  	    
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.error("EXECPTION");
			} finally {
				LOGGER.info("Test complete!");
			}
	}
		
	@Test
	public void testGetCustomer()
			throws ServiceLoadException, CustomerException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(CustomerManager.class));
			LOGGER.info(CustomerManager.getCustomer(id));
			LOGGER.info("testGetCustomer PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("EXECPTION");
		} finally {
			LOGGER.info("Test complete!");
		}
	}
}