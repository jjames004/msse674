

package jbr.springmvc.business.managerTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ UserManagerTest.class, CakeManagerTest.class, CustomerManagerTest.class, EmpManagerTest.class })
public class AllManagerTest {

}
