
/* JUnit 4 */


package jbr.springmvc.business.managerTest;

import junit.framework.TestCase;

import jbr.springmvc.business.manager.UserManager;
import jbr.springmvc.business.manager.ManagerSuperType;
import jbr.springmvc.business.exception.ServiceLoadException;
import jbr.springmvc.model.User;
import jbr.springmvc.services.exception.UserException;
import jbr.springmvc.service.factory.SvcFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

public class UserManagerTest extends TestCase {
	
	
	public UserManagerTest( String constructor )
	{ super( constructor );
	}
	
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(UserManagerTest.class.getName());
	
	private SvcFactory svcFactory;
	private User user;
	private UserManager userMgr;
	private String username; 
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		User user1 = new User("username", "password", "firstname", "lastname", "email", "address", 123456789); 
		
		username = user1.getUsername();

	}
		

	@Test
	public void testRegisterUser() 
			throws ServiceLoadException, UserException {
		
			try {
				assertTrue(ManagerSuperType.class.isAssignableFrom(UserManager.class));
		        LOGGER.info("testCreateUser PASSED");	  	    
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.error("EXECPTION");
			} finally {
				LOGGER.info("Test complete!");
			}
	}
		
	@Test
	public void testValidateUser()
			throws ServiceLoadException, UserException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(UserManager.class));
			LOGGER.info("testGetUser PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("EXECPTION");
		} finally {
			LOGGER.info("Test complete!");
		}
	}
	
	@Test
	public void testReadUser()
			throws ServiceLoadException, UserException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(UserManager.class));
			LOGGER.info("testGetUser PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("EXECPTION");
		} finally {
			LOGGER.info("Test complete!");
		}
	}
}