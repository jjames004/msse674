
/* JUnit 4 */


package jbr.springmvc.business.managerTest;

import junit.framework.TestCase;

import jbr.springmvc.business.manager.EmpManager;
import jbr.springmvc.business.manager.ManagerSuperType;
import jbr.springmvc.business.exception.ServiceLoadException;
import jbr.springmvc.model.Emp;
import jbr.springmvc.services.exception.EmpException;
import jbr.springmvc.service.factory.SvcFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;

public class EmpManagerTest extends TestCase {
	
	
	public EmpManagerTest( String constructor )
	{ super( constructor );
	}
	
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(EmpManagerTest.class.getName());
	
	private SvcFactory svcFactory;
	private Emp emp;
	private EmpManager empMgr;
	private int id; 
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		Emp emp1 = new Emp("name", 123, "baker"); 
		
		id = emp1.getId();

	}
		

	@Test
	public void testCreateEmp() 
			throws ServiceLoadException, EmpException {
		
			try {
				assertTrue(ManagerSuperType.class.isAssignableFrom(EmpManager.class));
		  	    assertTrue(EmpManager.createEmp(emp));
		        LOGGER.info("testCreateEmp PASSED");	  	    
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.error("EXECPTION");
			} finally {
				LOGGER.info("Test complete!");
			}
	}
		
	@Test
	public void testGetEmp()
			throws ServiceLoadException, EmpException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(EmpManager.class));
			LOGGER.info(EmpManager.getEmp(id));
			LOGGER.info("testGetEmp PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("EXECPTION");
		} finally {
			LOGGER.info("Test complete!");
		}
	}
}