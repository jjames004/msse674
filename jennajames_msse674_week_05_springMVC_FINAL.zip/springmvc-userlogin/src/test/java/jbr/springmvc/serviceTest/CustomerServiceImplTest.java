package jbr.springmvc.serviceTest;

import junit.framework.Assert;
import junit.framework.TestCase;

import java.io.IOException;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import jbr.springmvc.business.exception.ServiceLoadException;
import jbr.springmvc.model.Composite;
import jbr.springmvc.model.Customer;
import jbr.springmvc.services.exception.CustomerException;
import jbr.springmvc.service.CustomerServiceImpl;
import jbr.springmvc.service.CustomerService;
import jbr.springmvc.service.factory.SvcFactory;

public class CustomerServiceImplTest extends TestCase {
	
	public CustomerServiceImplTest( String constructor )
	{ super( constructor );
	}

	// declare new factory and customer objects
	private SvcFactory svcFactory;
	
	private Customer customer; 

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();
		
		customer = new Customer();

	}
	
	// test Interface and Implementation classes
	@Test
	public void testCustomerService() 
			throws ClassNotFoundException, CustomerException, IOException {
    	
 		CustomerService customerService;
		try {
			customerService = (CustomerService)svcFactory.getService(CustomerService.NAME);
	  	    assertTrue(customerService instanceof CustomerServiceImpl);
	        System.out.println("testCustomerService PASSED");	  	    
		} catch (ServiceLoadException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Test complete!");
		}
	}
	
	// test CRUD operations
	
	@Autowired
	  private CustomerService customerService;
	
	@Test
	  public void testSaveCustomer() {
	    customer = new Customer();
	    customer.setId(100);
	    customer.setFirstname("joe");
	    customer.setLastname("dirt");
	    customer.setEmail("dirt@aol.com");
	    
	  }
	
	@Test
	  public void testUpdateCustomer() {
	    customer = new Customer();
	    customer.setId(101);
	    customer.setFirstname("peggy");
	    customer.setLastname("hill");
	    customer.setEmail("peggyhill@aol.com");
	    
	  }
	
	@Test
	  public void testDeleteCustomer() {
	    customer.getId();  
	  }
	
	@Test
	  public void testReadCustomer() {
	    customer.getId();  
	  }


}
