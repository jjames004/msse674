package jbr.springmvc.serviceTest;

import junit.framework.Assert;
import junit.framework.TestCase;

import java.io.IOException;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import jbr.springmvc.business.exception.ServiceLoadException;
import jbr.springmvc.model.Composite;
import jbr.springmvc.model.User;
import jbr.springmvc.services.exception.UserException;
import jbr.springmvc.service.UserServiceImpl;
import jbr.springmvc.service.UserService;
import jbr.springmvc.service.factory.SvcFactory;

public class UserServiceImplTest extends TestCase {
	
	public UserServiceImplTest( String constructor )
	{ super( constructor );
	}

	// declare new factory and customer objects
	private SvcFactory svcFactory;
	
	private User user; 

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();
		
		user = new User();

	}
	
	// test Interface and Implementation classes
	@Test
	public void testUserService() 
			throws ClassNotFoundException, UserException, IOException {
    	
 		UserService userService;
		try {
			userService = (UserService)svcFactory.getService(UserService.NAME);
	  	    assertTrue(userService instanceof UserServiceImpl);
	        System.out.println("testUserService PASSED");	  	    
		} catch (ServiceLoadException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Test complete!");
		}
	}
	
	// test CRUD operations
	
	@Autowired
	  private UserService userService;
	
	@Test
	  public void testSaveUser() {
	    user = new User();
	    user.setUsername("fatcat");
	    user.setPassword("password");
	    user.setFirstname("chubby");
	    user.setLastname("kitty");
	    user.setEmail("chubbycat@gmail.com");
	    user.setAddress("123 abc street");
	    user.setPhone(1112223333);
	    
	  }
	
	@Test
	  public void testUpdateUser() {
	    user = new User();
	    user.setUsername("happy");
	    user.setPassword("password");
	    user.setFirstname("happy");
	    user.setLastname("cat");
	    user.setEmail("happycat@gmail.com");
	    user.setAddress("123 abc street");
	    user.setPhone(1112223333);
	    
	  }
	
	@Test
	  public void testDeleteUser() {
	    user.getUsername();  
	  }
	
	@Test
	  public void testReadUser() {
	    user.getUsername();  
	  }


}
