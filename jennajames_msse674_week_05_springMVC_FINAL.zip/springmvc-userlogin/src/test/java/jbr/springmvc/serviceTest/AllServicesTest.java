

package jbr.springmvc.serviceTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)


@SuiteClasses({ SvcFactoryTest.class, CakeServiceImplTest.class, 
UserServiceImplTest.class, EmpServiceImplTest.class, CustomerServiceImplTest.class })

public class AllServicesTest {

}
