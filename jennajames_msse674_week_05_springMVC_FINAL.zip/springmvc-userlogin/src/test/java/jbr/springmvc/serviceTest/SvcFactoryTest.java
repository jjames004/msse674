package jbr.springmvc.serviceTest;

import org.junit.Before;
import org.junit.Test;

import jbr.springmvc.business.exception.ServiceLoadException;
import jbr.springmvc.model.Composite;
import jbr.springmvc.service.factory.SvcFactory;
import jbr.springmvc.service.CakeServiceImpl;
import jbr.springmvc.service.CustomerServiceImpl;
import jbr.springmvc.service.UserServiceImpl;
import jbr.springmvc.service.EmpServiceImpl;

import junit.framework.TestCase;

import jbr.springmvc.service.CakeService;
import jbr.springmvc.service.UserService;
import jbr.springmvc.service.CustomerService;
import jbr.springmvc.service.EmpService;

public class SvcFactoryTest extends TestCase {
	
	public SvcFactoryTest( String constructor )
	{ super( constructor );
	}

	SvcFactory svcFactory;
	Composite comp;
	
	
	@Before
	public void setUp() throws Exception {
		svcFactory = new SvcFactory();
	}
	 
	/**
     * assert userService as an instance of UserServiceImpl
     */
		@Test
		public void testGetUserService() {
	 		UserService userService;
			try {
				userService = (UserService)svcFactory.getService(UserService.NAME);
		  	    assertTrue(userService instanceof UserServiceImpl);
		        System.out.println("testGetUserService PASSED");	  	    
			} catch (ServiceLoadException e) {
				e.printStackTrace();
			}
		}
		
		
		
		/**
	     * assert customerService as an instance of CustomerServiceImpl
	     */
		
		@Test
		public void testGetCustomerService() {
	 		CustomerService customerService;
			try {
				customerService = (CustomerService)svcFactory.getService(CustomerService.NAME);
		  	    assertTrue(customerService instanceof CustomerServiceImpl);
		        System.out.println("testGetCustomerService PASSED");	  	    
			} catch (ServiceLoadException e) {
				e.printStackTrace();
			}
		}
		
		/**
	     * assert cakeService as an instance of CakeServiceImpl
	     */
		
		@Test
		public void testGetCakeService() {
	 		CakeService cakeService;
			try {
				cakeService = (CakeService)svcFactory.getService(CakeService.NAME);
		  	    assertTrue(cakeService instanceof CakeServiceImpl);
		        System.out.println("testGetCakeService PASSED");	  	    
			} catch (ServiceLoadException e) {
				e.printStackTrace();
			}
		}
		
		/**
	     * assert empService as an instance of EmpServiceImpl
	     */
		
		@Test
		public void testGetEmpService() {
	 		EmpService empService;
			try {
				empService = (EmpService)svcFactory.getService(EmpService.NAME);
		  	    assertTrue(empService instanceof EmpServiceImpl);
		        System.out.println("testGetEmpService PASSED");	  	    
			} catch (ServiceLoadException e) {
				e.printStackTrace();
			}
		}

}
