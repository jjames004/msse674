package jbr.springmvc.serviceTest;

import junit.framework.Assert;
import junit.framework.TestCase;

import java.io.IOException;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import jbr.springmvc.business.exception.ServiceLoadException;
import jbr.springmvc.model.Composite;
import jbr.springmvc.model.Emp;
import jbr.springmvc.services.exception.EmpException;
import jbr.springmvc.service.EmpServiceImpl;
import jbr.springmvc.service.EmpService;
import jbr.springmvc.service.factory.SvcFactory;

public class EmpServiceImplTest extends TestCase {
	
	public EmpServiceImplTest( String constructor )
	{ super( constructor );
	}

	// declare new factory and customer objects
	private SvcFactory svcFactory;
	
	private Emp emp; 

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();
		
		emp = new Emp();

	}
	
	// test Interface and Implementation classes
	@Test
	public void testEmpService() 
			throws ClassNotFoundException, EmpException, IOException {
    	
 		EmpService empService;
		try {
			empService = (EmpService)svcFactory.getService(EmpService.NAME);
	  	    assertTrue(empService instanceof EmpServiceImpl);
	        System.out.println("testEmpService PASSED");	  	    
		} catch (ServiceLoadException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Test complete!");
		}
	}
	
	// test CRUD operations
	
	@Autowired
	  private EmpService empService;
	
	@Test
	  public void testSaveEmp() {
	    emp = new Emp();
	    emp.setId(100);
	    emp.setName("sally");
	    emp.setSalary(123);
	    emp.setDesignation("baker");
	    
	  }
	
	@Test
	  public void testUpdateEmp() {
	    emp = new Emp();
	    emp.setId(101);
	    emp.setName("bobby");
	    emp.setSalary(456);
	    emp.setDesignation("sales");
	    
	  }
	
	@Test
	  public void testDeleteEmp() {
	    emp.getId();  
	  }
	
	@Test
	  public void testReadEmp() {
	    emp.getId();  
	  }


}
