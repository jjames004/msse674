package jbr.springmvc.serviceTest;

import junit.framework.Assert;
import junit.framework.TestCase;

import java.io.IOException;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import jbr.springmvc.business.exception.ServiceLoadException;
import jbr.springmvc.model.Composite;
import jbr.springmvc.model.Cake;
import jbr.springmvc.services.exception.CakeException;
import jbr.springmvc.service.CakeServiceImpl;
import jbr.springmvc.service.CakeService;
import jbr.springmvc.service.factory.SvcFactory;

public class CakeServiceImplTest extends TestCase {
	
	public CakeServiceImplTest( String constructor )
	{ super( constructor );
	}

	// declare new factory and customer objects
	private SvcFactory svcFactory;
	
	private Cake cake; 

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();
		
		cake = new Cake();

	}
	
	// test Interface and Implementation classes
	@Test
	public void testCakeService() 
			throws ClassNotFoundException, CakeException, IOException {
    	
 		CakeService cakeService;
		try {
			cakeService = (CakeService)svcFactory.getService(CakeService.NAME);
	  	    assertTrue(cakeService instanceof CakeServiceImpl);
	        System.out.println("testCakeService PASSED");	  	    
		} catch (ServiceLoadException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Test complete!");
		}
	}
	
	// test CRUD operations
	
	@Autowired
	  private CakeService cakeService;
	
	@Test
	  public void testSaveCake() {
	    cake = new Cake();
	    cake.setId(100);
	    cake.setFlavor("cherry");
	    cake.setPrice(123);
	    cake.setTiers(4);
	    
	  }
	
	@Test
	  public void testUpdateCake() {
	    cake = new Cake();
	    cake.setId(101);
	    cake.setFlavor("strawberry");
	    cake.setPrice(345);
	    cake.setTiers(3);
	    
	  }
	
	@Test
	  public void testDeleteCake() {
	    cake.getId();  
	  }
	
	@Test
	  public void testReadCake() {
	    cake.getId();  
	  }


}
