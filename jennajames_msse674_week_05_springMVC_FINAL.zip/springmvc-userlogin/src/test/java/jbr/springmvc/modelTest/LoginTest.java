package jbr.springmvc.modelTest;

import org.junit.Test;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jbr.springmvc.model.Login;

import junit.framework.TestCase;

public class LoginTest extends TestCase {
	
	public LoginTest( String constructor )
	{ super( constructor );
	}

	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(LoginTest.class.getName());
	
    Login admin1 = new Login("username", "password"); 
	
    Login admin2 = new Login("username", "password");

    @Test
	public void testEqualAdmin() {
		
		// calling the override equals method
		LOGGER.info("Test equal method override: " + admin1.equals(admin2));
		
		if(admin1.equals(admin2)) {
			LOGGER.error("The admin objects are equal!");
		} else {
			LOGGER.info("The admin objects are NOT equal!");
		}
	}
    
    @Test
	public void testValidateAdmin() {
    	assertNotNull(admin2.getUsername());
    	assertNotNull(admin2.getPassword());
    }
}
