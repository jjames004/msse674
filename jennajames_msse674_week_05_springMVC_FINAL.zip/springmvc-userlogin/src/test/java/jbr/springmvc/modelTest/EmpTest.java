package jbr.springmvc.modelTest;

import org.junit.Test;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jbr.springmvc.model.Emp;

import junit.framework.TestCase;

public class EmpTest extends TestCase {
	
	public EmpTest( String constructor )
	{ super( constructor );
	}

	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(EmpTest.class.getName());
	
    Emp emp1 = new Emp("name", 123, "baker"); 
	
    Emp emp2 = new Emp("name1", 123, "baker1");

    @Test
	public void testEqualCake() {
		
		// calling the override equals method
		LOGGER.info("Test equal method override: " + emp1.equals(emp2));
		
		if(emp1.equals(emp2)) {
			LOGGER.error("The employee objects are equal!");
		} else {
			LOGGER.info("The employee objects are NOT equal!");
		}
	}
    

    @Test
	public void testValidateCake() {
    	assertNotNull(emp2.getName());
    	assertNotNull(emp2.getSalary());
    	assertNotNull(emp2.getDesignation());
    }

}
