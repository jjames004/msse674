package jbr.springmvc.modelTest;

import org.junit.Test;

import jbr.springmvc.model.Customer;

import junit.framework.TestCase;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CustomerTest extends TestCase {
	
	public CustomerTest( String constructor )
	{ super( constructor );
	}

	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CustomerTest.class.getName());
	
    Customer c1 = new Customer("firstname", "lastname", "email"); 
	
    Customer c2 = new Customer("firstname1", "lastname1", "email1");

    @Test
	public void testEqualsCustomer() {
		
		// calling the override equals method
		LOGGER.info("Test equal method override: " + c1.equals(c2));
		
		if(c1.equals(c2)) {
			LOGGER.error("The customer objects are equal!");
		} else {
			LOGGER.info("The customer objects are NOT equal!");
		}
	}
    

    @Test
	public void testValidateCustomer() {
    	assertNotNull(c2.getFirstname());
    	assertNotNull(c2.getLastname());
    	assertNotNull(c2.getEmail());
 
    }

}
