package jbr.springmvc.modelTest;

import org.junit.Test;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jbr.springmvc.model.Cake;

import junit.framework.TestCase;

public class CakeTest extends TestCase {
	
	public CakeTest( String constructor )
	{ super( constructor );
	}

	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CakeTest.class.getName());
	
    Cake cake1 = new Cake("flavor", 123, 3); 
	
    Cake cake2 = new Cake("flavor2", 345, 2);

    @Test
	public void testEqualCake() {
		
		// calling the override equals method
		LOGGER.info("Test equal method override: " + cake1.equals(cake2));
		
		if(cake1.equals(cake2)) {
			LOGGER.error("The cake objects are equal!");
		} else {
			LOGGER.info("The cake objects are NOT equal!");
		}
	}
    

    @Test
	public void testValidateCake() {
    	assertNotNull(cake2.getFlavor());
    	assertNotNull(cake2.getPrice());
    	assertNotNull(cake2.getTiers());
    }

}
