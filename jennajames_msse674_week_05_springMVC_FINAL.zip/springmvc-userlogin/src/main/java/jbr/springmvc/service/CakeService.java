package jbr.springmvc.service;

import java.util.List;

import jbr.springmvc.model.Cake;


public interface CakeService {
	
	public final String NAME = "CakeService";
	
	public int save(Cake p);
	public int update(Cake p);
	public int delete(int id);
	public Cake getCakeById(int id);
	public List<Cake> getCakes();
}
