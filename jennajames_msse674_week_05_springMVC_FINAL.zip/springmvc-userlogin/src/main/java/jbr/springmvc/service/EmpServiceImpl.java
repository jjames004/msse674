package jbr.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import jbr.springmvc.dao.EmpDao;
import jbr.springmvc.model.Emp;


public class EmpServiceImpl implements EmpService {

  @Autowired
  public EmpDao empDao;

@Override
public int save(Emp p) {
	return empDao.save(p);
}

@Override
public int update(Emp p) {
	return empDao.update(p);
}

@Override
public int delete(int id) {
	return empDao.delete(id);
}

@Override
public Emp getEmpById(int id) {
	return empDao.getEmpById(id);
}

@Override
public List<Emp> getEmployees() {
	return empDao.getEmployees();
}


  
}
