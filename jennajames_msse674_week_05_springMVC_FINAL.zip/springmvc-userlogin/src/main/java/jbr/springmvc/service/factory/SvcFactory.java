package jbr.springmvc.service.factory;
import jbr.springmvc.business.exception.ServiceLoadException;
import jbr.springmvc.service.IService;
import jbr.springmvc.services.manager.PropertyManager;


// copy from MSSE672 sample code
//DO NOT CHANGE

public class SvcFactory {
	
	// Singleton Pattern.
	public SvcFactory() {
	}

	private static SvcFactory svcFactory = new SvcFactory();

	public static SvcFactory getInstance() {
		return svcFactory;
	}
	
	
	// call the service interface, i.e. ICustomerService
	public IService getService(String serviceName) throws ServiceLoadException {
		try {
			// generic
			Class<?> c = Class.forName(getImplName(serviceName));
			return (IService) c.newInstance();
		} catch (Exception excp) {
			serviceName = serviceName + " not loaded";
			throw new ServiceLoadException(serviceName, excp);
		}
	}
	
	// call the implementation class for a given service, i.e. ReservationServiceImpl via the PropertyManager class
	private String getImplName(String serviceName) throws Exception {
		return PropertyManager.getPropertyValue(serviceName);
	}

} 
