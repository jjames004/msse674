package jbr.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import jbr.springmvc.dao.CakeDao;
import jbr.springmvc.model.Cake;


public class CakeServiceImpl implements CakeService {

  @Autowired
  public CakeDao cakeDao;

@Override
public int save(Cake p) {
	return cakeDao.save(p);
}

@Override
public int update(Cake p) {
	return cakeDao.update(p);
}

@Override
public int delete(int id) {
	return cakeDao.delete(id);
}

@Override
public Cake getCakeById(int id) {
	return cakeDao.getCakeById(id);
}

@Override
public List<Cake> getCakes() {
	return cakeDao.getCakes();
}


  
}
