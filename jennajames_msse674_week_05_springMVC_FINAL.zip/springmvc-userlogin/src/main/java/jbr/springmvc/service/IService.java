package jbr.springmvc.service;

/**
 * generic interface from which all the service classes arise
 * 
 * all Service classes under com.bakeryorder.model.services.* implement IService interface
 * 
 * decouples the service and business layers
 */

public interface IService {

}  
