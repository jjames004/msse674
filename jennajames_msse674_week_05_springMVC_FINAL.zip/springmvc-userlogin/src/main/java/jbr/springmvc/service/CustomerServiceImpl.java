package jbr.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import jbr.springmvc.dao.CustomerDao;
import jbr.springmvc.model.Customer;


public class CustomerServiceImpl implements CustomerService {

  @Autowired
  public CustomerDao customerDao;

@Override
public int save(Customer p) {
	return customerDao.save(p);
}

@Override
public int update(Customer p) {
	return customerDao.update(p);
}

@Override
public int delete(int id) {
	return customerDao.delete(id);
}

@Override
public Customer getCustomerById(int id) {
	return customerDao.getCustomerById(id);
}

@Override
public List<Customer> getCustomers() {
	return customerDao.getCustomers();
}


  
}
