package jbr.springmvc.controller;   
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;   
import jbr.springmvc.model.Customer;  
import jbr.springmvc.dao.CustomerDaoImpl;  
@Controller  
public class CustomerController {  
    @Autowired  
    CustomerDaoImpl dao1;//will inject dao from xml file  
      
    /*It displays a form to input data, here "command" is a reserved request attribute 
     *which is used to display object data into form 
     */  
    @RequestMapping("/customerform")  
    public String showform(Model m){  
    	m.addAttribute("command", new Customer());
    	return "customerform"; 
    }  
    /*It saves object into database. The @ModelAttribute puts request data 
     *  into model object. You need to mention RequestMethod.POST method  
     *  because default request is GET*/  
    @RequestMapping(value="/savecustomer",method = RequestMethod.POST)  
    public String save(@ModelAttribute("customer") Customer cust){  
        dao1.save(cust);  
        return "redirect:/viewcustomer";//will redirect to viewemp request mapping  
    }  
    /* It provides list of employees in model object */  
    @RequestMapping("/viewcustomer")  
    public String viewcust(Model m){  
        List<Customer> list=dao1.getCustomers();  
        m.addAttribute("list",list);
        return "viewcustomer";  
    }  
    /* It displays object data into form for the given id.  
     * The @PathVariable puts URL data into variable.*/  
    @RequestMapping(value="/editcustomer/{id}")  
    public String edit(@PathVariable int id, Model m){  
        Customer cust=dao1.getCustomerById(id);  
        m.addAttribute("command",cust);
        return "customereditform";  
    }  
    /* It updates model object. */  
    @RequestMapping(value="/editsavecustomer",method = RequestMethod.POST)  
    public String editsave(@ModelAttribute("customer") Customer cust){  
        dao1.update(cust);  
        return "redirect:/viewcustomer";  
    }  
    /* It deletes record for the given id in URL and redirects to /viewemp */  
    @RequestMapping(value="/deletecustomer/{id}",method = RequestMethod.GET)  
    public String delete(@PathVariable int id){  
        dao1.delete(id);  
        return "redirect:/viewcustomer";  
    }   
}  