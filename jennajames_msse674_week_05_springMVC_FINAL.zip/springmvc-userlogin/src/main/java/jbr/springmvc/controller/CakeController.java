package jbr.springmvc.controller;   
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;   
import jbr.springmvc.model.Cake;  
import jbr.springmvc.dao.CakeDaoImpl;  
@Controller  
public class CakeController {  
    @Autowired  
    CakeDaoImpl dao2;//will inject dao from xml file  
      
    /*It displays a form to input data, here "command" is a reserved request attribute 
     *which is used to display object data into form 
     */  
    @RequestMapping("/cakeform")  
    public String showform(Model m){  
    	m.addAttribute("command", new Cake());
    	return "cakeform"; 
    }  
    /*It saves object into database. The @ModelAttribute puts request data 
     *  into model object. You need to mention RequestMethod.POST method  
     *  because default request is GET*/  
    @RequestMapping(value="/savecake",method = RequestMethod.POST)  
    public String save(@ModelAttribute("cake") Cake cust){  
        dao2.save(cust);  
        return "redirect:/viewcake";//will redirect to viewemp request mapping  
    }  
    /* It provides list of employees in model object */  
    @RequestMapping("/viewcake")  
    public String viewcake(Model m){  
        List<Cake> list=dao2.getCakes();  
        m.addAttribute("list",list);
        return "viewcake";  
    }  
    /* It displays object data into form for the given id.  
     * The @PathVariable puts URL data into variable.*/  
    @RequestMapping(value="/editcake/{id}")  
    public String edit(@PathVariable int id, Model m){  
        Cake cust=dao2.getCakeById(id);  
        m.addAttribute("command",cust);
        return "cakeeditform";  
    }  
    /* It updates model object. */  
    @RequestMapping(value="/editsavecake",method = RequestMethod.POST)  
    public String editsave(@ModelAttribute("cake") Cake cust){  
        dao2.update(cust);  
        return "redirect:/viewcake";  
    }  
    /* It deletes record for the given id in URL and redirects to /viewemp */  
    @RequestMapping(value="/deletecake/{id}",method = RequestMethod.GET)  
    public String delete(@PathVariable int id){  
        dao2.delete(id);  
        return "redirect:/viewcake";  
    }   
}  