package jbr.springmvc.dao;

import java.util.List;

import jbr.springmvc.model.Customer;


public interface CustomerDao {
	
	public int save(Customer p);
	public int update (Customer p);
	public int delete(int id);
	public Customer getCustomerById(int id);
	public List<Customer> getCustomers();
}
