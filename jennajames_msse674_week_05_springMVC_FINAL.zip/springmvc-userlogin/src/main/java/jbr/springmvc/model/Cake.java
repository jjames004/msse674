package jbr.springmvc.model;  
  
public class Cake {  
private int id;  
private String flavor;  
private float price;  
private float tiers;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFlavor() {
	return flavor;
}
public void setFlavor(String flavor) {
	this.flavor = flavor;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public float getTiers() {
	return tiers;
}
public void setTiers(float tiers) {
	this.tiers = tiers;
}   

// constructors
public Cake() {}
	
public Cake(String flavor, int price, int tiers) {
    super();
    this.flavor = flavor;
    this.price = price;
    this.tiers = tiers;
}

 public Cake(int id, String flavor, int price, int tiers) {
        super();
        this.id = id;
        this.flavor = flavor;
        this.price = price;
        this.tiers = tiers;

    }
  

}  