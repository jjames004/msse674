package jbr.springmvc.model;
import java.util.ArrayList;

public class Composite {
	
	// create an instance of each domain object
	private static User user;
	private static Cake cake;
	
	// associate multiple flights and reservations with a single customer
	private ArrayList<User> userList;
	private ArrayList<Cake> cakeList;
	
	// Constructor
	public Composite() {
	}

	// Getters
	public static User getUser() {
		return user;
	}

	public ArrayList<User> getUserList() {
		return userList;
	}

	public static Cake getCake() {
		return cake;
	}

	public ArrayList<Cake> getCakeList() {
		return cakeList;
	}


	// Setters
	public void setUser(User user) {
		this.user = user;
	}

	public void setUserList(ArrayList<User> userList) {
		this.userList = userList;
	}
	
	public void setCake(Cake cake) {
		this.cake = cake;
	}

	public void setCakeList(ArrayList<Cake> cakeList) {
		this.cakeList = cakeList;
	}

	
	// Clear all values
	public void clear() {
		user = null;
	}
	
	// toString

	@Override
	public String toString() {
		return "composite" + user + userList + cake + cakeList;
	}


	
}
