package jbr.springmvc.services.exception;

public class EmpException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	public EmpException(final String inMessage)
    {
        super(inMessage);
    }

	
	public EmpException(final String inMessage, final Throwable inNestedException)
    {
        super(inMessage, inNestedException);
    }


}
