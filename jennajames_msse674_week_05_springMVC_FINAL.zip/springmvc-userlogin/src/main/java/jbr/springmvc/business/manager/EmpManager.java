package jbr.springmvc.business.manager;

import jbr.springmvc.business.exception.*;
import jbr.springmvc.model.*;
import jbr.springmvc.service.factory.SvcFactory;
import jbr.springmvc.service.EmpService;
import jbr.springmvc.services.exception.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class EmpManager extends ManagerSuperType {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(EmpManager.class.getName());

	private static EmpManager myInstance;

	// constructor
	private EmpManager() {
	}

	// create only one Emp Manager
	public static synchronized EmpManager getInstance() {
		if (myInstance == null) {
			myInstance = new EmpManager();
		}
		return myInstance;
	}

	// generic method
	@Override
	public boolean performAction(String commandString, Composite composite) {
		// TODO Auto-generated method stub
		return false;
	}

	private int saveEmp(String commandString, Emp emp) throws EmpException {
			int isAdded = 0;
	
		SvcFactory svcFactory = SvcFactory.getInstance();
		EmpService empService;
	
		try {
			empService = (EmpService) svcFactory.getService(commandString);
			isAdded = empService.save(emp);
		} catch (ServiceLoadException e1) {
			LOGGER.error("EmpManager::failed to load Emp Service.");																			
		} catch (Exception ex) {
			LOGGER.error("EmpManager::Unknown error."); 
		}
	
		return isAdded;
	}
	
	private Emp readEmp(String commandString, Emp emp) throws EmpException {
		Emp isUpdated = new Emp();
		
		SvcFactory svcFactory = SvcFactory.getInstance();
		EmpService empService;
	
		try {
			empService = (EmpService) svcFactory.getService(commandString);
			isUpdated = empService.getEmpById(0);
		} catch (ServiceLoadException e1) {
			LOGGER.error("EmpManager::failed to load Emp Service.");																			
		} catch (Exception ex) {
			LOGGER.error("ERROR: EmpManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private int updateEmp(String commandString, Emp emp) throws EmpException {
			int isUpdated = 0;
			
		SvcFactory svcFactory = SvcFactory.getInstance();
		EmpService empService;
	
		try {
			empService = (EmpService) svcFactory.getService(commandString);
			isUpdated = empService.update(emp);
		} catch (ServiceLoadException e1) {
			LOGGER.error("EmpManager::failed to load Emp Service.");																			
		} catch (Exception ex) {
			LOGGER.error("ERROR: EmpManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private int deleteEmp(String commandString, Emp emp) throws EmpException {
		int isDeleted = 0;
		
	SvcFactory svcFactory = SvcFactory.getInstance();
	EmpService empService;

	try {
		empService = (EmpService) svcFactory.getService(commandString);
		isDeleted = empService.delete(1);
	} catch (ServiceLoadException e1) {
		LOGGER.error("EmpManager::failed to load Emp Service.");																			
	} catch (Exception ex) {
		LOGGER.error("ERROR: EmpManager::Unknown error."); 
	}

	return isDeleted;
}

// for testing
	public static boolean createEmp(Emp emp) {
		emp = new Emp("name", 123, "baker");
		return true;
	}

	public static char[] getEmp(int id) {
		Emp c1 = new Emp();
		return null;
	}


	
	

} // end EmpManager class
