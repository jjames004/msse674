package jbr.springmvc.business.manager;

import jbr.springmvc.business.exception.*;
import jbr.springmvc.model.*;
import jbr.springmvc.service.factory.SvcFactory;
import jbr.springmvc.service.CustomerService;
import jbr.springmvc.services.exception.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CustomerManager extends ManagerSuperType {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CustomerManager.class.getName());

	private static CustomerManager myInstance;

	// constructor
	private CustomerManager() {
	}

	// create only one Customer Manager
	public static synchronized CustomerManager getInstance() {
		if (myInstance == null) {
			myInstance = new CustomerManager();
		}
		return myInstance;
	}

	// generic method
	@Override
	public boolean performAction(String commandString, Composite composite) {
		// TODO Auto-generated method stub
		return false;
	}

	private int saveCustomer(String commandString, Customer customer) throws CustomerException {
			int isAdded = 0;
	
		SvcFactory svcFactory = SvcFactory.getInstance();
		CustomerService customerService;
	
		try {
			customerService = (CustomerService) svcFactory.getService(commandString);
			isAdded = customerService.save(customer);
		} catch (ServiceLoadException e1) {
			LOGGER.error("CustomerManager::failed to load Customer Service.");																			
		} catch (Exception ex) {
			LOGGER.error("CustomerManager::Unknown error."); 
		}
	
		return isAdded;
	}
	
	private Customer readCustomer(String commandString, Customer customer) throws CustomerException {
		Customer isUpdated = new Customer();
		
		SvcFactory svcFactory = SvcFactory.getInstance();
		CustomerService customerService;
	
		try {
			customerService = (CustomerService) svcFactory.getService(commandString);
			isUpdated = customerService.getCustomerById(0);
		} catch (ServiceLoadException e1) {
			LOGGER.error("CustomerManager::failed to load Customer Service.");																			
		} catch (Exception ex) {
			LOGGER.error("ERROR: CustomerManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private int updateCustomer(String commandString, Customer customer) throws CustomerException {
			int isUpdated = 0;
			
		SvcFactory svcFactory = SvcFactory.getInstance();
		CustomerService customerService;
	
		try {
			customerService = (CustomerService) svcFactory.getService(commandString);
			isUpdated = customerService.update(customer);
		} catch (ServiceLoadException e1) {
			LOGGER.error("CustomerManager::failed to load Customer Service.");																			
		} catch (Exception ex) {
			LOGGER.error("ERROR: CustomerManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private int deleteCustomer(String commandString, Customer customer) throws CustomerException {
		int isDeleted = 0;
		
	SvcFactory svcFactory = SvcFactory.getInstance();
	CustomerService customerService;

	try {
		customerService = (CustomerService) svcFactory.getService(commandString);
		isDeleted = customerService.delete(1);
	} catch (ServiceLoadException e1) {
		LOGGER.error("CustomerManager::failed to load Customer Service.");																			
	} catch (Exception ex) {
		LOGGER.error("ERROR: CustomerManager::Unknown error."); 
	}

	return isDeleted;
}

// for testing
	public static boolean createCustomer(Customer customer) {
		customer = new Customer("firstname", "lastname", "email");
		return true;
	}

	public static char[] getCustomer(int id) {
		Customer c1 = new Customer();
		return null;
	}


	
	

} // end CustomerManager class
