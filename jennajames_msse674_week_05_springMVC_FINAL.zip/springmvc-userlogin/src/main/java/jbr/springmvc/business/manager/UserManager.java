package jbr.springmvc.business.manager;

import jbr.springmvc.business.exception.*;
import jbr.springmvc.model.*;
import jbr.springmvc.service.factory.SvcFactory;
import jbr.springmvc.service.UserService;
import jbr.springmvc.services.exception.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class UserManager extends ManagerSuperType {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(UserManager.class.getName());

	private static UserManager myInstance;

	// constructor
	private UserManager() {
	}

	// create only one User Manager
	public static synchronized UserManager getInstance() {
		if (myInstance == null) {
			myInstance = new UserManager();
		}
		return myInstance;
	}

	// generic method
	@Override
	public boolean performAction(String commandString, Composite composite) {
		// TODO Auto-generated method stub
		return false;
	}

	private int registerUser(String commandString, User User) throws UserException {
			int isAdded = 0;
	
		SvcFactory svcFactory = SvcFactory.getInstance();
		UserService UserService;
	
		try {
			UserService = (UserService) svcFactory.getService(commandString);
			isAdded = UserService.register(User);
		} catch (ServiceLoadException e1) {
			LOGGER.error("UserManager::failed to load User Service.");																			
		} catch (Exception ex) {
			LOGGER.error("UserManager::Unknown error."); 
		}
	
		return isAdded;
	}
	
	private User validateUser(String commandString, Login login) throws UserException {
		User isValid = new User();
		
		SvcFactory svcFactory = SvcFactory.getInstance();
		UserService UserService;
	
		try {
			UserService = (UserService) svcFactory.getService(commandString);
			isValid = UserService.validateUser(login);
		} catch (ServiceLoadException e1) {
			LOGGER.error("UserManager::failed to load User Service.");																			
		} catch (Exception ex) {
			LOGGER.error("ERROR: UserManager::Unknown error."); 
		}
	
		return isValid;
	}
	
	private Login readUser(String commandString, Login login) throws UserException {
		Login isValid = new Login();
		
		SvcFactory svcFactory = SvcFactory.getInstance();
		UserService UserService;
	
		try {
			UserService = (UserService) svcFactory.getService(commandString);
			isValid = UserService.readUser(login);
		} catch (ServiceLoadException e1) {
			LOGGER.error("UserManager::failed to load User Service.");																			
		} catch (Exception ex) {
			LOGGER.error("ERROR: UserManager::Unknown error."); 
		}
	
		return isValid;
	}
	


// for testing
	public static boolean createUser(User User) {
		User = new User("username", "password", "firstname", "lastname", "email", "address", 123456789);
		return true;
	}

	public static char[] getUser(String username) {
		User c1 = new User();
		return null;
	}


	
	

} // end UserLoginManager class
