package jbr.springmvc.business.manager;

import jbr.springmvc.business.exception.*;
import jbr.springmvc.model.*;
import jbr.springmvc.service.factory.SvcFactory;
import jbr.springmvc.service.CakeService;
import jbr.springmvc.services.exception.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CakeManager extends ManagerSuperType {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CakeManager.class.getName());

	private static CakeManager myInstance;

	// constructor
	private CakeManager() {
	}

	// create only one Cake Manager
	public static synchronized CakeManager getInstance() {
		if (myInstance == null) {
			myInstance = new CakeManager();
		}
		return myInstance;
	}

	// generic method
	@Override
	public boolean performAction(String commandString, Composite composite) {
		// TODO Auto-generated method stub
		return false;
	}

	private int saveCake(String commandString, Cake cake) throws CakeException {
			int isAdded = 0;
	
		SvcFactory svcFactory = SvcFactory.getInstance();
		CakeService cakeService;
	
		try {
			cakeService = (CakeService) svcFactory.getService(commandString);
			isAdded = cakeService.save(cake);
		} catch (ServiceLoadException e1) {
			LOGGER.error("CakeManager::failed to load Cake Service.");																			
		} catch (Exception ex) {
			LOGGER.error("CakeManager::Unknown error."); 
		}
	
		return isAdded;
	}
	
	private Cake readCake(String commandString, Cake cake) throws CakeException {
		Cake isUpdated = new Cake();
		
		SvcFactory svcFactory = SvcFactory.getInstance();
		CakeService cakeService;
	
		try {
			cakeService = (CakeService) svcFactory.getService(commandString);
			isUpdated = cakeService.getCakeById(0);
		} catch (ServiceLoadException e1) {
			LOGGER.error("CakeManager::failed to load Cake Service.");																			
		} catch (Exception ex) {
			LOGGER.error("ERROR: CakeManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private int updateCake(String commandString, Cake cake) throws CakeException {
			int isUpdated = 0;
			
		SvcFactory svcFactory = SvcFactory.getInstance();
		CakeService cakeService;
	
		try {
			cakeService = (CakeService) svcFactory.getService(commandString);
			isUpdated = cakeService.update(cake);
		} catch (ServiceLoadException e1) {
			LOGGER.error("CakeManager::failed to load Cake Service.");																			
		} catch (Exception ex) {
			LOGGER.error("ERROR: CakeManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private int deleteCake(String commandString, Cake cake) throws CakeException {
		int isDeleted = 0;
		
	SvcFactory svcFactory = SvcFactory.getInstance();
	CakeService cakeService;

	try {
		cakeService = (CakeService) svcFactory.getService(commandString);
		isDeleted = cakeService.delete(1);
	} catch (ServiceLoadException e1) {
		LOGGER.error("CakeManager::failed to load Cake Service.");																			
	} catch (Exception ex) {
		LOGGER.error("ERROR: CakeManager::Unknown error."); 
	}

	return isDeleted;
}

// for testing
	public static boolean createCake(Cake cake) {
		cake = new Cake("flavor", 123, 3);
		return true;
	}

	public static char[] getCake(int id) {
		Cake c1 = new Cake();
		return null;
	}


	
	

} // end CakeLoginManager class
