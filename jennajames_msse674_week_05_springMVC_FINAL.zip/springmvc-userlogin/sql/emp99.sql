use msse674_week_05_mvc;

create table Emp99(
   id INT NOT NULL AUTO_INCREMENT,
   name VARCHAR(100) NOT NULL,
   salary INT NOT NULL,
   designation VARCHAR(100) NOT NULL,
   PRIMARY KEY ( id )
);