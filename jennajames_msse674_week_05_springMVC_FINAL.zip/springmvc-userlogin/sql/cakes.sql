use msse674_week_05_mvc;

create table cakes(
   id INT NOT NULL AUTO_INCREMENT,
   flavor VARCHAR(100) NOT NULL,
   price INT NOT NULL,
   tiers INT NOT NULL,
   PRIMARY KEY ( id )
);