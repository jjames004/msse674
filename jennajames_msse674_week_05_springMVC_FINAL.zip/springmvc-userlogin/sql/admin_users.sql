
USE msse674_week_05_mvc; 


CREATE TABLE users ( 
      `username`  VARCHAR(45) NOT NULL, 
      `password`  VARCHAR(45) NULL, 
      `firstname` VARCHAR(45) NOT NULL, 
      `lastname`  VARCHAR(45) NULL, 
      `email`     VARCHAR(45) NULL, 
      `address`   VARCHAR(45) NULL, 
      `phone`     INT NULL, 
      PRIMARY KEY (`username`))
      
/* users upkeep */
delete from users where username="test";
select * from users;