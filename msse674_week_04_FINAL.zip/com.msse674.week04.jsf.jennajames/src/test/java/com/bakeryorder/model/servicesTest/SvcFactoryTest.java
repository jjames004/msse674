package com.bakeryorder.model.servicesTest;

import org.junit.Before;
import org.junit.Test;

import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.AdminComposite;
import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.services.factory.SvcFactory;
import com.bakeryorder.model.services.cakeservice.CakeServiceImpl;
import com.bakeryorder.model.services.adminservice.AdminServiceImpl;
import com.bakeryorder.model.services.userservice.UserServiceImpl;

import junit.framework.TestCase;

import com.bakeryorder.model.services.cakeservice.ICakeService;
import com.bakeryorder.model.services.adminservice.IAdminService;
import com.bakeryorder.model.services.userservice.IUserService;

public class SvcFactoryTest extends TestCase {
	
	public SvcFactoryTest( String constructor )
	{ super( constructor );
	}

	SvcFactory svcFactory;
	Composite user;
	AdminComposite admin;
	
	
	@Before
	public void setUp() throws Exception {
		svcFactory = new SvcFactory();
	}
	 
	 /**
	     * Test SvcFactory to return the loginservice and assert it by 
	     * checking it is an instance of LoginSvcImpl
	     * 
	     * This should be true since LoginSvcImpl implements ILoginService.
	     * 
	     * Here we are casting SvcFactory output to ILoginSvc.
		 * This means that loginSvc will only see methods declared in
		 * the interface and implemented by LoginServiceImpl.
		 * This practice ensures data security.
		 * 
	     */
		@Test
		public void testGetLoginService() {
	 		IAdminService adminService;
			try {
				adminService = (IAdminService)svcFactory.getService(IAdminService.NAME);
		  	    assertTrue(adminService instanceof AdminServiceImpl);
		        System.out.println("testGetLoginService PASSED");	  	    
			} catch (ServiceLoadException e) {
				e.printStackTrace();
			}
		}
		
		/**
		 * Here we are casting SvcFactory to the login implementation class. 
		 * In addition to the methods declared in the interface 
		 * and implemented by the impl class, we can see any public 
		 * methods declared in the implementation class.
		 * This practice in a insecure way to access data.
		 * 
		 */
		
		@Test
		public void testGetLoginService1() {
	 		AdminServiceImpl adminSvcImpl;
			try {
				adminSvcImpl = (AdminServiceImpl)svcFactory.getService(AdminServiceImpl.NAME);
		  	    assertTrue(adminSvcImpl instanceof AdminServiceImpl);
		        System.out.println("testGetLoginService PASSED");	  	    
			} catch (ServiceLoadException e) {
				e.printStackTrace();
			}
		}
		
		
		/**
	     * assert customerService as an instance of UserServiceImpl
	     */
		
		@Test
		public void testGetCustomerService() {
	 		IUserService customerService;
			try {
				customerService = (IUserService)svcFactory.getService(IUserService.NAME);
		  	    assertTrue(customerService instanceof UserServiceImpl);
		        System.out.println("testGetCustomerService PASSED");	  	    
			} catch (ServiceLoadException e) {
				e.printStackTrace();
			}
		}
		
		/**
	     * assert cakeService as an instance of CakeServiceImpl
	     */
		
		@Test
		public void testGetCakeService() {
	 		ICakeService cakeService;
			try {
				cakeService = (ICakeService)svcFactory.getService(ICakeService.NAME);
		  	    assertTrue(cakeService instanceof CakeServiceImpl);
		        System.out.println("testGetCakeService PASSED");	  	    
			} catch (ServiceLoadException e) {
				e.printStackTrace();
			}
		}	

}
