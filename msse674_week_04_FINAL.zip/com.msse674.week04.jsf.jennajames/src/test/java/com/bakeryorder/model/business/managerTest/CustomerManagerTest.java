package com.bakeryorder.model.business.managerTest;

import org.junit.jupiter.api.Test;
import junit.framework.TestCase;

import com.bakeryorder.model.business.manager.CustomerManager;
import com.bakeryorder.model.business.manager.ManagerSuperType;
import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.CustomerBean;
import com.bakeryorder.model.services.exception.UserException;
import com.bakeryorder.model.services.factory.SvcFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CustomerManagerTest extends TestCase {
	
	public CustomerManagerTest( String constructor )
	{ super( constructor );
	}
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CustomerManagerTest.class.getName());
	
	private SvcFactory svcFactory;
	private CustomerBean user;
	private CustomerManager userMgr;
	private int id; 
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		CustomerBean user1 = new CustomerBean("name", "email", "password", "gender", "address"); 
		
		id = user1.getId();

	}
		

	@Test
	public void testCreateUser() 
			throws ServiceLoadException, UserException {
		
			try {
				assertTrue(ManagerSuperType.class.isAssignableFrom(CustomerManager.class));
		  	    assertTrue(CustomerManager.createUser(user));
		  	    LOGGER.info("testCreateUser PASSED");	  	    
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.error("EXECPTION");
			} finally {
				LOGGER.info("Test complete!");
			}
	}
		
	@Test
	public void testGetUser()
			throws ServiceLoadException, UserException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(CustomerManager.class));
			LOGGER.info(CustomerManager.getUser(id));
			LOGGER.info("testGetUser PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("EXECPTION");
		} finally {
			LOGGER.info("Test complete!");
		}
	}
}