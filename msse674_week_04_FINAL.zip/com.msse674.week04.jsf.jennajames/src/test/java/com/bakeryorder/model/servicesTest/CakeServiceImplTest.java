package com.bakeryorder.model.servicesTest;

import junit.framework.TestCase;

import java.io.IOException;

import org.junit.Test;

import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.CakeBean;
import com.bakeryorder.model.services.exception.CakeException;
import com.bakeryorder.model.services.cakeservice.CakeServiceImpl;
import com.bakeryorder.model.services.cakeservice.ICakeService;
import com.bakeryorder.model.services.factory.SvcFactory;

public class CakeServiceImplTest extends TestCase {
	
	public CakeServiceImplTest( String constructor )
	{ super( constructor );
	}

	// declare new factory and customer objects
	private SvcFactory svcFactory;
	private Composite cakebean;
	
	/** declare local value for object id
	 * @param int id This is a parameter of the getCustomer() method
	 * declared in the interface and executed in the implementation.
	 */
	private CakeBean cake; 

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		cakebean = new Composite();
		
		// link service parameter with object class variable
		cake = Composite.getCake();

	}
	
	@Test
	public void testStoreCake() 
			throws ClassNotFoundException, CakeException, IOException {
    	
 		ICakeService cakeService;
		try {
			cakeService = (ICakeService)svcFactory.getService(ICakeService.NAME);
	  	    assertTrue(cakeService instanceof CakeServiceImpl);
	  	    assertTrue(cakeService.createCake(cakebean));
	        System.out.println("testStoreCustomer PASSED");	  	    
		} catch (ServiceLoadException e) {
			e.printStackTrace();
		} catch (CakeException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Test complete!");
		}
	}

}
