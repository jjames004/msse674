

package com.bakeryorder.model.business.managerTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AdminManagerTest.class, CakeManagerTest.class, CustomerManagerTest.class })
public class AllManagerTest {

}
