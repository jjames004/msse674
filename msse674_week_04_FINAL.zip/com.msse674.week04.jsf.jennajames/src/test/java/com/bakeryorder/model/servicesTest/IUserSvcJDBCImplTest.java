package com.bakeryorder.model.servicesTest;

import junit.framework.TestCase;

import java.io.IOException;

import org.junit.Test;

import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.CustomerBean;
import com.bakeryorder.model.services.exception.UserException;
import com.bakeryorder.model.services.userservice.IUserService;
import com.bakeryorder.model.services.userservice.IUserSvcJDBCImpl;
import com.bakeryorder.model.services.factory.SvcFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class IUserSvcJDBCImplTest extends TestCase {
	
	public IUserSvcJDBCImplTest( String constructor )
	{ super( constructor );
	}
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(IUserSvcJDBCImplTest.class.getName());

	// declare new factory and customer objects
	private SvcFactory svcFactory;
	private Composite customer;
	
	/** declare local value for object id
	 * @param int id This is a parameter of the getCustomer() method
	 * declared in the interface and executed in the implementation.
	 */
	private CustomerBean user; 

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		customer = new Composite();
		
		// link service parameter with object class variable
		user = Composite.getUser();

	}
	
	@Test
	public void testStoreCustomer() 
			throws ClassNotFoundException, UserException, IOException {
    	
 		IUserService customerService;
		try {
			customerService = (IUserService)svcFactory.getService(IUserService.NAME);
	  	    assertTrue(customerService instanceof IUserSvcJDBCImpl);
	  	    assertTrue(customerService.createUser(customer));
	        LOGGER.info("testStoreCustomer PASSED");	  	    
		} catch (ServiceLoadException e) {
			e.printStackTrace();
		} catch (UserException e) {
			e.printStackTrace();
		} finally {
			LOGGER.info("Test complete!");
		}
	}

}
