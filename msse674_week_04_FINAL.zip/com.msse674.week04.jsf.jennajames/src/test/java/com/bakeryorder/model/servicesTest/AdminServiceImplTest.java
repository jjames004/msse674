package com.bakeryorder.model.servicesTest;

import junit.framework.TestCase;

import java.io.IOException;

import org.junit.Test;

import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.AdminComposite;
import com.bakeryorder.model.domain.LoginBean;
import com.bakeryorder.model.services.exception.AdminException;
import com.bakeryorder.model.services.adminservice.AdminServiceImpl;
import com.bakeryorder.model.services.adminservice.IAdminService;
import com.bakeryorder.model.services.factory.SvcFactory;

public class AdminServiceImplTest extends TestCase {
	
	public AdminServiceImplTest( String constructor )
	{ super( constructor );
	}

	// declare new factory and customer objects
	private SvcFactory svcFactory;
	private AdminComposite loginbean;
	
	/** declare local value for object id
	 * @param int id This is a parameter of the getCustomer() method
	 * declared in the interface and executed in the implementation.
	 */
	private LoginBean login; 

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		loginbean = new AdminComposite();
		
		// link service parameter with object class variable
		login = AdminComposite.getAdmin();

	}
	
	@Test
	public void testStoreAdmin() 
			throws ClassNotFoundException, AdminException, IOException {
    	
 		IAdminService adminService;
		try {
			adminService = (IAdminService)svcFactory.getService(IAdminService.NAME);
	  	    assertTrue(adminService instanceof AdminServiceImpl);
	  	    assertTrue(adminService.createUser(loginbean));
	        System.out.println("testStoreCustomer PASSED");	  	    
		} catch (ServiceLoadException e) {
			e.printStackTrace();
		} catch (AdminException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Test complete!");
		}
	}
}
