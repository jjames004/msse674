
/* JUnit 4 */


package com.bakeryorder.model.business.managerTest;

import org.junit.jupiter.api.Test;
import junit.framework.TestCase;

import com.bakeryorder.model.business.manager.CakeManager;
import com.bakeryorder.model.business.manager.ManagerSuperType;
import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.CakeBean;
import com.bakeryorder.model.services.exception.CakeException;
import com.bakeryorder.model.services.factory.SvcFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CakeManagerTest extends TestCase {
	
	
	public CakeManagerTest( String constructor )
	{ super( constructor );
	}
	
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CakeManagerTest.class.getName());
	
	private SvcFactory svcFactory;
	private CakeBean cake;
	private CakeManager cakeMgr;
	private int id; 
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		CakeBean cake1 = new CakeBean("flavor", "filling", "icing", "tiers", "decor"); 
		
		id = cake1.getId();

	}
		

	@Test
	public void testCreateCake() 
			throws ServiceLoadException, CakeException {
		
			try {
				assertTrue(ManagerSuperType.class.isAssignableFrom(CakeManager.class));
		  	    assertTrue(CakeManager.createCake(cake));
		        LOGGER.info("testCreateCake PASSED");	  	    
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.error("EXECPTION");
			} finally {
				LOGGER.info("Test complete!");
			}
	}
		
	@Test
	public void testGetCake()
			throws ServiceLoadException, CakeException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(CakeManager.class));
			LOGGER.info(CakeManager.getCake(id));
			LOGGER.info("testGetCake PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("EXECPTION");
		} finally {
			LOGGER.info("Test complete!");
		}
	}
}