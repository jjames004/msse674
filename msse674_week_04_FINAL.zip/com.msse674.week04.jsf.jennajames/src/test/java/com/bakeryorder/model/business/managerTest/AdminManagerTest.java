/* JUnit 4 */

package com.bakeryorder.model.business.managerTest;

import org.junit.jupiter.api.Test;
import junit.framework.TestCase;

import com.bakeryorder.model.business.manager.AdminManager;
import com.bakeryorder.model.business.manager.ManagerSuperType;
import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.LoginBean;
import com.bakeryorder.model.services.exception.AdminException;
import com.bakeryorder.model.services.factory.SvcFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class AdminManagerTest extends TestCase {
	
	public AdminManagerTest( String constructor )
	{ super( constructor );
	}
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(AdminManagerTest.class.getName());
    
    
	
	private SvcFactory svcFactory;
	private LoginBean Admin;
	private AdminManager userMgr;
	private String uname; 
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		LoginBean admin1 = new LoginBean("password", "user", "email"); 
		
		uname = admin1.getUser();

	}
		

	@Test
	public void testcreateAdmin() 
			throws ServiceLoadException, AdminException {
		
			try {
				assertTrue(ManagerSuperType.class.isAssignableFrom(AdminManager.class));
		  	    assertTrue(AdminManager.createAdmin(Admin));
		  	    LOGGER.info("testCreateAdmin PASSED");	  	    
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.error("EXECPTION");
			} finally {
				LOGGER.info("Test complete!");
			}
	}
		
	@Test
	public void testGetAdmin()
			throws ServiceLoadException, AdminException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(AdminManager.class));
			LOGGER.info(AdminManager.getAdmin(uname));
			LOGGER.info("testGetAdmin PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("EXECPTION");
		} finally {
			LOGGER.info("Test complete!");
		}
	}
}
