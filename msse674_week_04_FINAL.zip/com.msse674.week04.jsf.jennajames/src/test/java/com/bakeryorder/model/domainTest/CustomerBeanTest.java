package com.bakeryorder.model.domainTest;

import org.junit.Test;

import com.bakeryorder.model.domain.CustomerBean;

import junit.framework.TestCase;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CustomerBeanTest extends TestCase {
	
	public CustomerBeanTest( String constructor )
	{ super( constructor );
	}

	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CustomerBeanTest.class.getName());
	
    CustomerBean user1 = new CustomerBean("name", "email", "password", "gender", "address"); 
	
    CustomerBean user2 = new CustomerBean("name", "email", "password", "gender", "address");

    @Test
	public void testEqualsCustomer() {
		
		// calling the override equals method
		LOGGER.info("Test equal method override: " + user1.equals(user2));
		
		if(user1.equals(user2)) {
			LOGGER.error("The customer objects are equal!");
		} else {
			LOGGER.info("The customer objects are NOT equal!");
		}
	}
    

    @Test
	public void testValidateCustomer() {
    	assertNotNull(user2.getName());
    	assertNotNull(user2.getEmail());
    	assertNotNull(user2.getPassword());
    	assertNotNull(user2.getGender());
    	assertNotNull(user2.getAddress());
    }

}
