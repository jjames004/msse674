package com.bakeryorder.model.servicesTest;

import junit.framework.TestCase;

import java.io.IOException;

import org.junit.Test;

import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.AdminComposite;
import com.bakeryorder.model.domain.LoginBean;
import com.bakeryorder.model.services.exception.AdminException;
import com.bakeryorder.model.services.adminservice.IAdminSvcJDBCImpl;
import com.bakeryorder.model.services.adminservice.IAdminService;
import com.bakeryorder.model.services.factory.SvcFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class IAdminSvcJDBCImplTest extends TestCase {
	
	public IAdminSvcJDBCImplTest( String constructor )
	{ super( constructor );
	}

	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(IAdminSvcJDBCImpl.class.getName());
	
	// declare new factory and customer objects
	private SvcFactory svcFactory;
	private AdminComposite loginbean;
	
	/** declare local value for object id
	 * @param int id This is a parameter of the getCustomer() method
	 * declared in the interface and executed in the implementation.
	 */
	private LoginBean login; 

	/**
	 * @throws java.lang.Exception
	 */
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		loginbean = new AdminComposite();
		
		// link service parameter with object class variable
		login = AdminComposite.getAdmin();

	}
	
	@Test
	public void testStoreAdmin() 
			throws ClassNotFoundException, AdminException, IOException {
    	
 		IAdminService adminService;
		try {
			adminService = (IAdminService)svcFactory.getService(IAdminService.NAME);
	  	    assertTrue(adminService instanceof IAdminSvcJDBCImpl);
	  	    assertTrue(adminService.createUser(loginbean));
	        LOGGER.info("testStoreCustomer PASSED");	  	    
		} catch (ServiceLoadException e) {
			e.printStackTrace();
		} catch (AdminException e) {
			e.printStackTrace();
		} finally {
			LOGGER.info("Test complete!");
		}
	}

}
