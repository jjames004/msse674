

package com.bakeryorder.model.servicesTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)

// week 03 implementation classes
//@SuiteClasses({ SvcFactoryTest.class, UserServiceImplTest.class, 
//	AdminServiceImplTest.class, CakeServiceImplTest.class, SvcFactoryTest.class })

// week 04 implementation classes with JDBC and JSF
@SuiteClasses({ SvcFactoryTest.class, IUserSvcJDBCImplTest.class, 
IAdminSvcJDBCImplTest.class, ICakeSvcJDBCImplTest.class })

public class AllServicesTest {

}
