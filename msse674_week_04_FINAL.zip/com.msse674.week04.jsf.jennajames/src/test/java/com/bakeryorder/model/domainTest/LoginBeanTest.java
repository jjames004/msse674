package com.bakeryorder.model.domainTest;

import org.junit.Test;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bakeryorder.model.domain.LoginBean;

import junit.framework.TestCase;

public class LoginBeanTest extends TestCase {
	
	public LoginBeanTest( String constructor )
	{ super( constructor );
	}

	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(LoginBeanTest.class.getName());
	
    LoginBean admin1 = new LoginBean("password", "user", "email"); 
	
    LoginBean admin2 = new LoginBean("password", "user", "email");

    @Test
	public void testEqualAdmin() {
		
		// calling the override equals method
		LOGGER.info("Test equal method override: " + admin1.equals(admin2));
		
		if(admin1.equals(admin2)) {
			LOGGER.error("The admin objects are equal!");
		} else {
			LOGGER.info("The admin objects are NOT equal!");
		}
	}
    
    @Test
	public void testValidateAdmin() {
    	assertNotNull(admin2.getUser());
    	assertNotNull(admin2.getEmail());
    	assertNotNull(admin2.getPwd());
    }
}
