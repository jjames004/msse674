package com.bakeryorder.model.domainTest;

import org.junit.Test;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bakeryorder.model.domain.CakeBean;

import junit.framework.TestCase;

public class CakeBeanTest extends TestCase {
	
	public CakeBeanTest( String constructor )
	{ super( constructor );
	}

	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CakeBeanTest.class.getName());
	
    CakeBean cake1 = new CakeBean("flavor", "filling", "icing", "tiers", "decor"); 
	
    CakeBean cake2 = new CakeBean("flavor", "filling", "icing", "tiers", "decor");

    @Test
	public void testEqualCake() {
		
		// calling the override equals method
		LOGGER.info("Test equal method override: " + cake1.equals(cake2));
		
		if(cake1.equals(cake2)) {
			LOGGER.error("The cake objects are equal!");
		} else {
			LOGGER.info("The cake objects are NOT equal!");
		}
	}
    

    @Test
	public void testValidateCake() {
    	assertNotNull(cake2.getFlavor());
    	assertNotNull(cake2.getFilling());
    	assertNotNull(cake2.getIcing());
    	assertNotNull(cake2.getTiers());
    	assertNotNull(cake2.getDecor());
    }

}
