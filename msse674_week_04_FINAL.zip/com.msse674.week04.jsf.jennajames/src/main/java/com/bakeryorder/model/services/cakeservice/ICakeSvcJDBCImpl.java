package com.bakeryorder.model.services.cakeservice;

import java.util.ArrayList;

import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.CakeBean;
import com.bakeryorder.model.services.exception.CakeException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import javax.faces.context.FacesContext;

import com.bakeryorder.model.domain.CakeBean;

public class ICakeSvcJDBCImpl implements ICakeService {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(ICakeSvcJDBCImpl.class.getName());

	@Override
	public boolean createCake(Composite composite) throws CakeException {
		LOGGER.info("CakeServiceImpl::createCake().");
		boolean isSuccess = false;
		
		try {
			CakeBean create = composite.getCake();
			isSuccess = true;
		} catch (Exception ex){
			throw new CakeException("ERROR:  There was a problem with the CakeService.", ex);
		} 
		return isSuccess;
	}
	
	@Override
	public boolean readCake(Composite composite) throws CakeException {
		LOGGER.info("CakeServiceImpl::readCake().");
		boolean isSuccess = false;
		
		try {
			CakeBean read = composite.getCake();
			isSuccess = true;
		} catch (Exception ex){
			throw new CakeException("ERROR:  There was a problem with the CakeService.", ex);
		} 
		return isSuccess;
	}

	@Override
	public boolean updateCake(Composite composite) throws CakeException {
		LOGGER.info("INFO: CakeServiceImpl::updateCake().");
		boolean isSuccess = false;
		
		try {
			CakeBean update = composite.getCake();
			isSuccess = true;
		} catch (Exception ex){
			throw new CakeException("ERROR:  There was a problem with the CakeService.", ex);
		} 
		return isSuccess;
	}

	

	@Override
	public boolean deleteCake(Composite composite) throws CakeException {
		LOGGER.info("INFO: CakeServiceImpl::deleteCake().");
		boolean isSuccess = false;
		
		try {
			CakeBean delete = composite.getCake();
			isSuccess = true;
		} catch (Exception ex){
			throw new CakeException("ERROR:  There was a problem with the CakeService.", ex);
		} 
		return isSuccess;
	}
	
	public static Statement stmtObj;
	public static Connection connObj;
	public static ResultSet resultSetObj;
	public static PreparedStatement pstmt;

	/* Method To Establish Database Connection */
	public static Connection getConnection(){  
		try{ 
			
			
//			Class.forName("com.mysql.cj.jdbc.Driver");     
//			String db_url ="jdbc:mysql://localhost:3306/msse674_week_04",
//					db_userName = "root",
//					db_password = "Z0obaby3";
//			connObj = DriverManager.getConnection(db_url,db_userName,db_password);  
			
			Class.forName("com.mysql.cj.jdbc.Driver");     
			String db_url ="jdbc:mysql://jennajames-msse674.chem6ns37jb0.us-west-1.rds.amazonaws.com:3306/jennajames_msse674?user=jenna&password=Z0obaby3",
					db_userName = "jenna",
					db_password = "Z0obaby3";
			connObj = DriverManager.getConnection(db_url,db_userName,db_password);  			
			
			
		} catch(Exception sqlException) {  
			sqlException.printStackTrace();
		}  
		return connObj;
	}

	/* Method To Fetch The Cake Records From Database */
	public static ArrayList<CakeBean> getCakesListFromDB() {
		ArrayList<CakeBean> cakesList = new ArrayList<CakeBean>();  
		try {
			stmtObj = getConnection().createStatement();    
			resultSetObj = stmtObj.executeQuery("select * from cake_record");    
			while(resultSetObj.next()) {  
				CakeBean stuObj = new CakeBean(); 
				stuObj.setId(resultSetObj.getInt("cake_id"));  
				stuObj.setFlavor(resultSetObj.getString("cake_flavor"));  
				stuObj.setFilling(resultSetObj.getString("cake_filling"));  
				stuObj.setIcing(resultSetObj.getString("cake_icing"));  
				stuObj.setTiers(resultSetObj.getString("cake_tiers"));  
				stuObj.setDecor(resultSetObj.getString("cake_decor"));  
				cakesList.add(stuObj);  
			}   
			System.out.println("Total Records Fetched: " + cakesList.size());
			connObj.close();
		} catch(Exception sqlException) {
			sqlException.printStackTrace();
		} 
		return cakesList;
	}

	/* Method Used To Save New Cake Record In Database */
	public static String saveCakeDetailsInDB(CakeBean newCakeObj) {
		int saveResult = 0;
		String navigationResult = "";
		try {      
			pstmt = getConnection().prepareStatement("insert into cake_record (cake_flavor, cake_filling, cake_icing, cake_tiers, cake_decor) values (?, ?, ?, ?, ?)");			
			pstmt.setString(1, newCakeObj.getFlavor());
			pstmt.setString(2, newCakeObj.getFilling());
			pstmt.setString(3, newCakeObj.getIcing());
			pstmt.setString(4, newCakeObj.getTiers());
			pstmt.setString(5, newCakeObj.getDecor());
			saveResult = pstmt.executeUpdate();
			connObj.close();
		} catch(Exception sqlException) {
			sqlException.printStackTrace();
		}
		if(saveResult !=0) {
			navigationResult = "cakesList.xhtml?faces-redirect=true";
		} else {
			navigationResult = "createCake.xhtml?faces-redirect=true";
		}
		return navigationResult;
	}

	/* Method Used To Edit Cake Record In Database */
	public static String editCakeRecordInDB(int cakeId) {
		CakeBean editRecord = null;
		System.out.println("editCakeRecordInDB() : Cake Id: " + cakeId);

		/* Setting The Particular Cake Details In Session */
		Map<String,Object> sessionMapObj = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

		try {
			stmtObj = getConnection().createStatement();    
			resultSetObj = stmtObj.executeQuery("select * from cake_record where cake_id = "+cakeId);    
			if(resultSetObj != null) {
				resultSetObj.next();
				editRecord = new CakeBean(); 
				editRecord.setId(resultSetObj.getInt("cake_id"));
				editRecord.setFlavor(resultSetObj.getString("cake_flavor"));
				editRecord.setFilling(resultSetObj.getString("cake_filling"));
				editRecord.setIcing(resultSetObj.getString("cake_icing"));
				editRecord.setTiers(resultSetObj.getString("cake_tiers"));
				editRecord.setDecor(resultSetObj.getString("cake_decor")); 
			}
			sessionMapObj.put("editRecordObj", editRecord);
			connObj.close();
		} catch(Exception sqlException) {
			sqlException.printStackTrace();
		}
		return "/editCake.xhtml?faces-redirect=true";
	}

	/* Method Used To Update Cake Record In Database */
	public static String updateCakeDetailsInDB(CakeBean updateCakeObj) {
		try {
			pstmt = getConnection().prepareStatement("update cake_record set cake_flavor=?, cake_filling=?, cake_icing=?, cake_tiers=?, cake_decor=? where cake_id=?");    
			pstmt.setString(1,updateCakeObj.getFlavor());  
			pstmt.setString(2,updateCakeObj.getFilling());  
			pstmt.setString(3,updateCakeObj.getIcing());  
			pstmt.setString(4,updateCakeObj.getTiers());  
			pstmt.setString(5,updateCakeObj.getDecor());  
			pstmt.setInt(6,updateCakeObj.getId());  
			pstmt.executeUpdate();
			connObj.close();			
		} catch(Exception sqlException) {
			sqlException.printStackTrace();
		}
		return "/cakesList.xhtml?faces-redirect=true";
	}

	/* Method Used To Delete Cake Record From Database */
	public static String deleteCakeRecordInDB(int cakeId){
		System.out.println("deleteCakeRecordInDB() : Cake Id: " + cakeId);
		try {
			pstmt = getConnection().prepareStatement("delete from cake_record where cake_id = "+cakeId);  
			pstmt.executeUpdate();  
			connObj.close();
		} catch(Exception sqlException){
			sqlException.printStackTrace();
		}
		return "/cakesList.xhtml?faces-redirect=true";
	}


}
