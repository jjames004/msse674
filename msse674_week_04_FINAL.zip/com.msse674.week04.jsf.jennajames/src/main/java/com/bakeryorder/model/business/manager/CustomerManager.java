package com.bakeryorder.model.business.manager;

import com.bakeryorder.model.business.exception.*;
import com.bakeryorder.model.domain.*;
import com.bakeryorder.model.services.factory.SvcFactory;
import com.bakeryorder.model.services.userservice.IUserService;
import com.bakeryorder.model.services.exception.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CustomerManager extends ManagerSuperType {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CustomerManager.class.getName());

	private static CustomerManager myInstance;

	// constructor
	private CustomerManager() {
	}

	// create only one User Manager
	public static synchronized CustomerManager getInstance() {
		if (myInstance == null) {
			myInstance = new CustomerManager();
		}
		return myInstance;
	}

	// generic method
	@Override
	public boolean performAction(String commandString, Composite composite) {
		// TODO Auto-generated method stub
		return false;
	}

	private boolean createUser(String commandString, Composite composite) {
			boolean isAdded = false;
	
		SvcFactory svcFactory = SvcFactory.getInstance();
		IUserService userService;
	
		try {
			userService = (IUserService) svcFactory.getService(commandString);
			isAdded = userService.createUser(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("UserManager::failed to load User Service.");																			
		} catch (UserException re) {
			LOGGER.error("UserManager::createUser() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("UserManager::Unknown error."); 
		}
	
		return isAdded;
	}
	
	private boolean readUser(String commandString, Composite composite) {
		boolean isUpdated = false;
		
		SvcFactory svcFactory = SvcFactory.getInstance();
		IUserService userService;
	
		try {
			userService = (IUserService) svcFactory.getService(commandString);
			isUpdated = userService.updateUser(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("UserManager::failed to load User Service.");																			
		} catch (UserException re) {
			LOGGER.error("UserManager::readUser() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("ERROR: UserManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private boolean updateUser(String commandString, Composite composite) {
			boolean isUpdated = false;
			
		SvcFactory svcFactory = SvcFactory.getInstance();
		IUserService userService;
	
		try {
			userService = (IUserService) svcFactory.getService(commandString);
			isUpdated = userService.updateUser(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("UserManager::failed to load User Service.");																			
		} catch (UserException re) {
			LOGGER.error("UserManager::updateUser() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("ERROR: UserManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private boolean deleteUser(String commandString, Composite composite) {
		boolean isUpdated = false;
		
	SvcFactory svcFactory = SvcFactory.getInstance();
	IUserService userService;

	try {
		userService = (IUserService) svcFactory.getService(commandString);
		isUpdated = userService.deleteUser(composite);
	} catch (ServiceLoadException e1) {
		LOGGER.error("UserManager::failed to load User Service.");																			
	} catch (UserException re) {
		LOGGER.error("UserManager::deleteUser() failed"); 
		re.printStackTrace();
	} catch (Exception ex) {
		LOGGER.error("ERROR: UserManager::Unknown error."); 
	}

	return isUpdated;
}

// for testing
	public static boolean createUser(CustomerBean user) {
		user = new CustomerBean("name", "email", "password", "gender", "address");
		return true;
	}

	public static char[] getUser(int id) {
		CustomerBean u1 = new CustomerBean();
		return null;
	}
	
	

} // end UserLoginManager class
