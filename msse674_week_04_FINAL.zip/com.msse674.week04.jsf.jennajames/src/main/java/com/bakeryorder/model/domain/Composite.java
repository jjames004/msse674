package com.bakeryorder.model.domain;
import java.util.ArrayList;

public class Composite {
	
	// create an instance of each domain object
	private static CustomerBean user;
	private static CakeBean cake;
	
	// associate multiple flights and reservations with a single customer
	private ArrayList<CustomerBean> userList;
	private ArrayList<CakeBean> cakeList;
	
	// Constructor
	public Composite() {
	}

	// Getters
	public static CustomerBean getUser() {
		return user;
	}

	public ArrayList<CustomerBean> getUserList() {
		return userList;
	}

	public static CakeBean getCake() {
		return cake;
	}

	public ArrayList<CakeBean> getCakeList() {
		return cakeList;
	}


	// Setters
	public void setUser(CustomerBean user) {
		this.user = user;
	}

	public void setUserList(ArrayList<CustomerBean> userList) {
		this.userList = userList;
	}
	
	public void setCake(CakeBean cake) {
		this.cake = cake;
	}

	public void setCakeList(ArrayList<CakeBean> cakeList) {
		this.cakeList = cakeList;
	}

	
	// Clear all values
	public void clear() {
		user = null;
	}
	
	// toString

	@Override
	public String toString() {
		return "composite" + user + userList + cake + cakeList;
	}


	
}
