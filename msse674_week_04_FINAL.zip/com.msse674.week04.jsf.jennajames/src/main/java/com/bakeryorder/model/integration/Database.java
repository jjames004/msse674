package com.bakeryorder.model.integration;

import java.sql.Connection;
import java.sql.DriverManager;
 
public class Database {
 
    public static Connection getConnection() {
        try {
        	
//        	  local database connection
//            Class.forName("com.mysql.cj.jdbc.Driver"); 
//            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/msse674_week_04",
//                    "root", "Z0obaby3");
//            return con;
        	
//      	AWS database connection
          Class.forName("com.mysql.cj.jdbc.Driver"); 
          Connection con = DriverManager.getConnection("jdbc:mysql://jennajames-msse674.chem6ns37jb0.us-west-1.rds.amazonaws.com:3306/jennajames_msse674?user=jenna&password=Z0obaby3",
                  "jenna", "Z0obaby3");
          return con;
        	
        	
        } catch (Exception ex) {
            System.out.println("Database.getConnection() Error -->" + ex.getMessage());
            return null;
        }
    }
 
    public static void close(Connection con) {
        try {
            con.close();
        } catch (Exception ex) {
        }
    }
}