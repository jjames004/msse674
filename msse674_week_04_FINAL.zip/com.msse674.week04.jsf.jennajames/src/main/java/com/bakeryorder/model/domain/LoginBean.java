package com.bakeryorder.model.domain;

import java.io.Serializable;
import java.sql.SQLException;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import com.bakeryorder.model.auth.SessionUtils;
import com.bakeryorder.model.services.adminservice.IAdminSvcJDBCImpl;

@ManagedBean
@SessionScoped
public class LoginBean implements Serializable {

    private static final long serialVersionUID = 1L;
	
	private String pwd;
	private String msg, user;
	private String email;

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	//validate login
	public String validateUsernamePassword() throws ClassNotFoundException, SQLException {

//	//logout event, invalidate session
//	public String logout() {
//		HttpSession session = SessionUtils.getSession();
//		session.invalidate();
//		return "login";
		
        boolean result = IAdminSvcJDBCImpl.validate(user, pwd, email);
        if (result) {
            // get Http Session and store user
            HttpSession session = SessionUtils.getSession();
            session.setAttribute("username", user);
            session.setAttribute("email", email);
 
            return "admin";
        } else {
 
            FacesContext.getCurrentInstance().addMessage(
                    null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN,
                    "Invalid Login!",
                    "Please Try Again!"));
 
            // invalidate session, and redirect to other pages
 
            //message = "Invalid Login. Please Try Again!";
            return "login";
        }

	} // end validateUsernamePassword()
        
        public String logout() {
            HttpSession session = SessionUtils.getSession();
            session.invalidate();
            return "login";
         }
        
	// constructors
	public LoginBean() {}
	
	public LoginBean(String pwd, String user, String email) {
        super();
        this.pwd = pwd;
        this.user = user;
        this.email = email;
    }
	
}
