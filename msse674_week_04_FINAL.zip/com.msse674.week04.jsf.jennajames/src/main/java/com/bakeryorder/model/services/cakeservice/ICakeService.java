package com.bakeryorder.model.services.cakeservice;

import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.services.IService;
import com.bakeryorder.model.services.exception.CakeException;

public interface ICakeService extends IService {
	
	public final String NAME = "ICakeService";
	
	// list the methods available through the specific interface
	// each method accepts an instance of the composite class
	
	public boolean createCake(Composite composite) throws CakeException;
	public boolean readCake(Composite composite) throws CakeException;
	public boolean updateCake(Composite composite) throws CakeException;
	public boolean deleteCake(Composite composite) throws CakeException;

}
