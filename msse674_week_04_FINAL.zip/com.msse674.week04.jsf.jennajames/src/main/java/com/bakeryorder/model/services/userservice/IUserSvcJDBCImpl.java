package com.bakeryorder.model.services.userservice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import javax.faces.context.FacesContext;

import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.CustomerBean;
import com.bakeryorder.model.services.exception.UserException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class IUserSvcJDBCImpl implements IUserService {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(IUserSvcJDBCImpl.class.getName());

	@Override
	public boolean createUser(Composite composite) throws UserException {
		LOGGER.info("CakeServiceImpl::createUser().");
		boolean isSuccess = false;
		
		try {
			CustomerBean create = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}
	
	@Override
	public boolean readUser(Composite composite) throws UserException {
		LOGGER.info("CakeServiceImpl::readUser().");
		boolean isSuccess = false;
		
		try {
			CustomerBean read = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}

	@Override
	public boolean updateUser(Composite composite) throws UserException {
		LOGGER.info("INFO: CakeServiceImpl::updateUser().");
		boolean isSuccess = false;
		
		try {
			CustomerBean update = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}

	

	@Override
	public boolean deleteUser(Composite composite) throws UserException {
		LOGGER.info("INFO: CakeServiceImpl::deleteUser().");
		boolean isSuccess = false;
		
		try {
			CustomerBean delete = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}
	
	public static Statement stmtObj;
	public static Connection connObj;
	public static ResultSet resultSetObj;
	public static PreparedStatement pstmt;

	/* Method To Establish Database Connection */
	public static Connection getConnection(){  
		try{ 
			
			
//			Class.forName("com.mysql.cj.jdbc.Driver");     
//			String db_url ="jdbc:mysql://localhost:3306/msse674_week_04",
//					db_userName = "root",
//					db_password = "Z0obaby3";
//			connObj = DriverManager.getConnection(db_url,db_userName,db_password);  
			
			Class.forName("com.mysql.cj.jdbc.Driver");     
			String db_url ="jdbc:mysql://jennajames-msse674.chem6ns37jb0.us-west-1.rds.amazonaws.com:3306/jennajames_msse674?user=jenna&password=Z0obaby3",
					db_userName = "jenna",
					db_password = "Z0obaby3";
			connObj = DriverManager.getConnection(db_url,db_userName,db_password);  
			
			
			
		} catch(Exception sqlException) {  
			sqlException.printStackTrace();
		}  
		return connObj;
	}

	/* Method To Fetch The Customer Records From Database */
	public static ArrayList<CustomerBean> getCustomersListFromDB() {
		ArrayList<CustomerBean> customersList = new ArrayList<CustomerBean>();  
		try {
			stmtObj = getConnection().createStatement();    
			resultSetObj = stmtObj.executeQuery("select * from customer_record");    
			while(resultSetObj.next()) {  
				CustomerBean stuObj = new CustomerBean(); 
				stuObj.setId(resultSetObj.getInt("customer_id"));  
				stuObj.setName(resultSetObj.getString("customer_name"));  
				stuObj.setEmail(resultSetObj.getString("customer_email"));  
				stuObj.setPassword(resultSetObj.getString("customer_password"));  
				stuObj.setGender(resultSetObj.getString("customer_gender"));  
				stuObj.setAddress(resultSetObj.getString("customer_address"));  
				customersList.add(stuObj);  
			}   
			System.out.println("Total Records Fetched: " + customersList.size());
			connObj.close();
		} catch(Exception sqlException) {
			sqlException.printStackTrace();
		} 
		return customersList;
	}

	/* Method Used To Save New Customer Record In Database */
	public static String saveCustomerDetailsInDB(CustomerBean newCustomerObj) {
		int saveResult = 0;
		String navigationResult = "";
		try {      
			pstmt = getConnection().prepareStatement("insert into customer_record (customer_name, customer_email, customer_password, customer_gender, customer_address) values (?, ?, ?, ?, ?)");			
			pstmt.setString(1, newCustomerObj.getName());
			pstmt.setString(2, newCustomerObj.getEmail());
			pstmt.setString(3, newCustomerObj.getPassword());
			pstmt.setString(4, newCustomerObj.getGender());
			pstmt.setString(5, newCustomerObj.getAddress());
			saveResult = pstmt.executeUpdate();
			connObj.close();
		} catch(Exception sqlException) {
			sqlException.printStackTrace();
		}
		if(saveResult !=0) {
			navigationResult = "customersList.xhtml?faces-redirect=true";
		} else {
			navigationResult = "createCustomer.xhtml?faces-redirect=true";
		}
		return navigationResult;
	}

	/* Method Used To Edit Customer Record In Database */
	public static String editCustomerRecordInDB(int customerId) {
		CustomerBean editRecord = null;
		System.out.println("editCustomerRecordInDB() : Customer Id: " + customerId);

		/* Setting The Particular Customer Details In Session */
		Map<String,Object> sessionMapObj = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

		try {
			stmtObj = getConnection().createStatement();    
			resultSetObj = stmtObj.executeQuery("select * from customer_record where customer_id = "+customerId);    
			if(resultSetObj != null) {
				resultSetObj.next();
				editRecord = new CustomerBean(); 
				editRecord.setId(resultSetObj.getInt("customer_id"));
				editRecord.setName(resultSetObj.getString("customer_name"));
				editRecord.setEmail(resultSetObj.getString("customer_email"));
				editRecord.setGender(resultSetObj.getString("customer_gender"));
				editRecord.setAddress(resultSetObj.getString("customer_address"));
				editRecord.setPassword(resultSetObj.getString("customer_password")); 
			}
			sessionMapObj.put("editRecordObj", editRecord);
			connObj.close();
		} catch(Exception sqlException) {
			sqlException.printStackTrace();
		}
		return "/editCustomer.xhtml?faces-redirect=true";
	}

	/* Method Used To Update Customer Record In Database */
	public static String updateCustomerDetailsInDB(CustomerBean updateCustomerObj) {
		try {
			pstmt = getConnection().prepareStatement("update customer_record set customer_name=?, customer_email=?, customer_password=?, customer_gender=?, customer_address=? where customer_id=?");    
			pstmt.setString(1,updateCustomerObj.getName());  
			pstmt.setString(2,updateCustomerObj.getEmail());  
			pstmt.setString(3,updateCustomerObj.getPassword());  
			pstmt.setString(4,updateCustomerObj.getGender());  
			pstmt.setString(5,updateCustomerObj.getAddress());  
			pstmt.setInt(6,updateCustomerObj.getId());  
			pstmt.executeUpdate();
			connObj.close();			
		} catch(Exception sqlException) {
			sqlException.printStackTrace();
		}
		return "/customersList.xhtml?faces-redirect=true";
	}

	/* Method Used To Delete Customer Record From Database */
	public static String deleteCustomerRecordInDB(int customerId){
		System.out.println("deleteCustomerRecordInDB() : Customer Id: " + customerId);
		try {
			pstmt = getConnection().prepareStatement("delete from customer_record where customer_id = "+customerId);  
			pstmt.executeUpdate();  
			connObj.close();
		} catch(Exception sqlException){
			sqlException.printStackTrace();
		}
		return "/customersList.xhtml?faces-redirect=true";
	}


}
