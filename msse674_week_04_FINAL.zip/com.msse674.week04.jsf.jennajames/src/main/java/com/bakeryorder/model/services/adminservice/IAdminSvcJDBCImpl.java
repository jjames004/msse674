package com.bakeryorder.model.services.adminservice;

import java.util.ArrayList;

import com.bakeryorder.model.domain.LoginBean;
import com.bakeryorder.model.integration.Database;
import com.bakeryorder.model.domain.AdminComposite;
import com.bakeryorder.model.services.exception.AdminException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class IAdminSvcJDBCImpl implements IAdminService {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(IAdminSvcJDBCImpl.class.getName());

	@Override
	public boolean createUser(AdminComposite composite) throws AdminException {
		LOGGER.info("AdminServiceImpl::createUser().");
		boolean isSuccess = false;
		
		try {
			LoginBean create = composite.getAdmin();
			isSuccess = true;
		} catch (Exception ex){
			throw new AdminException("ERROR:  There was a problem with the AdminService.", ex);
		} 
		return isSuccess;
	}
	
	@Override
	public boolean readUser(AdminComposite composite) throws AdminException {
		LOGGER.info("AdminServiceImpl::readUser().");
		boolean isSuccess = false;
		
		try {
			LoginBean read = composite.getAdmin();
			isSuccess = true;
		} catch (Exception ex){
			throw new AdminException("ERROR:  There was a problem with the AdminService.", ex);
		} 
		return isSuccess;
	}

	@Override
	public boolean updateUser(AdminComposite composite) throws AdminException {
		LOGGER.info("INFO: AdminServiceImpl::updateUser().");
		boolean isSuccess = false;
		
		try {
			LoginBean update = composite.getAdmin();
			isSuccess = true;
		} catch (Exception ex){
			throw new AdminException("ERROR:  There was a problem with the AdminService.", ex);
		} 
		return isSuccess;
	}

	

	@Override
	public boolean deleteUser(AdminComposite composite) throws AdminException {
		LOGGER.info("INFO: AdminServiceImpl::deleteUser().");
		boolean isSuccess = false;
		
		try {
			LoginBean delete = composite.getAdmin();
			isSuccess = true;
		} catch (Exception ex){
			throw new AdminException("ERROR:  There was a problem with the AdminService.", ex);
		} 
		return isSuccess;
	}
	
	public static boolean validate(String user, String password, String email) throws SQLException, ClassNotFoundException {
		Connection con = null;
        
        PreparedStatement ps = null;
       
    
    try {
        con = Database.getConnection();
        ps = con.prepareStatement(
                "select admin_name, admin_password, admin_email from admin_record where admin_name= ? and admin_password= ? and admin_email=? ");
        ps.setString(1, user);
        ps.setString(2, password);
        ps.setString(3, email);

        ResultSet rs = ps.executeQuery();
        if (rs.next()) // found
        {
            System.out.println(rs.getString("admin_name"));
            System.out.println(rs.getString("admin_email"));
            return true;
        }
        else {
            return false;
        }
    } catch (Exception ex) {
        System.out.println("Error in login() -->" + ex.getMessage());
        return false;
    } finally {
        Database.close(con);
    }

}


}
