package com.bakeryorder.model.domain;

import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import com.bakeryorder.model.services.cakeservice.ICakeSvcJDBCImpl;

@ManagedBean 
@RequestScoped
public class CakeBean {

	private int id;  
	private String flavor;  
	private String filling;  
	private String icing;
	private String tiers;
	private String decor;  
	

	public ArrayList<CakeBean> cakesListFromDB;

	public int getId() {
		return id;	
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFlavor() {
		return flavor;
	}

	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}

	public String getFilling() {
		return filling;
	}

	public void setFilling(String filling) {
		this.filling = filling;
	}

	public String getIcing() {
		return icing;
	}

	public void setIcing(String icing) {
		this.icing = icing;
	}

	public String getTiers() {
		return tiers;
	}

	public void setTiers(String tiers) {
		this.tiers = tiers;
	}

	public String getDecor() {
		return decor;
	}

	public void setDecor(String decor) {
		this.decor = decor;
	}  
	
	/* Method Will Avoid Multiple Calls To DB For Fetching The Cakes Records. If This Is Not Used & Data Is Fetched From Getter Method, JSF DataTable Will Make Multiple Calls To DB*/
	@PostConstruct
	public void init() {
		cakesListFromDB = ICakeSvcJDBCImpl.getCakesListFromDB();
	}

	/* Method Used To Fetch All Records From The Database */
	public ArrayList<CakeBean> cakesList() {
		return cakesListFromDB;
	}
	
	/* Method Used To Save New Cake Record */
	public String saveCakeDetails(CakeBean newCakeObj) {
		return ICakeSvcJDBCImpl.saveCakeDetailsInDB(newCakeObj);
	}
	
	/* Method Used To Edit Cake Record */
	public String editCakeRecord(int cakeId) {
		return ICakeSvcJDBCImpl.editCakeRecordInDB(cakeId);
	}
	
	/* Method Used To Update Cake Record */
	public String updateCakeDetails(CakeBean updateCakeObj) {
		return ICakeSvcJDBCImpl.updateCakeDetailsInDB(updateCakeObj);
	}
	
	/* Method Used To Delete Cake Record */
	public String deleteCakeRecord(int cakeId) {
		return ICakeSvcJDBCImpl.deleteCakeRecordInDB(cakeId);
	}
	
	// constructors
	public CakeBean() {}
		
	public CakeBean(String flavor, String filling, String icing, String tiers, String decor) {
	    super();
	    this.flavor = flavor;
	    this.filling = filling;
	    this.icing = icing;
	    this.tiers = tiers;
	    this.decor = decor;

	}
	
	 public CakeBean(int id, String flavor, String filling, String icing, String tiers, String decor) {
	        super();
	        this.id = id;
	        this.flavor = flavor;
		    this.filling = filling;
		    this.icing = icing;
		    this.tiers = tiers;
		    this.decor = decor;
	
	    }
}