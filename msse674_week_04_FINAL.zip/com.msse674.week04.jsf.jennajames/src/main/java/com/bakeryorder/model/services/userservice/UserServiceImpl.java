package com.bakeryorder.model.services.userservice;

import java.util.ArrayList;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import javax.faces.context.FacesContext;


import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.CustomerBean;
import com.bakeryorder.model.services.exception.UserException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class UserServiceImpl implements IUserService {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(UserServiceImpl.class.getName());

	@Override
	public boolean createUser(Composite composite) throws UserException {
		LOGGER.info("CakeServiceImpl::createUser().");
		boolean isSuccess = false;
		
		try {
			CustomerBean create = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}
	
	@Override
	public boolean readUser(Composite composite) throws UserException {
		LOGGER.info("CakeServiceImpl::readUser().");
		boolean isSuccess = false;
		
		try {
			CustomerBean read = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}

	@Override
	public boolean updateUser(Composite composite) throws UserException {
		LOGGER.info("INFO: CakeServiceImpl::updateUser().");
		boolean isSuccess = false;
		
		try {
			CustomerBean update = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}

	

	@Override
	public boolean deleteUser(Composite composite) throws UserException {
		LOGGER.info("INFO: CakeServiceImpl::deleteUser().");
		boolean isSuccess = false;
		
		try {
			CustomerBean delete = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}
	



}
