package com.bakeryorder.model.domain;
import java.util.ArrayList;

public class AdminComposite {
	
	// create an instance of each domain object
	private static LoginBean admin;
	private CustomerBean user;
	
	private ArrayList<LoginBean> adminList;
	private ArrayList<CustomerBean> userList;
	
	// Constructor
	public AdminComposite() {
	}

	// Getters
	public static LoginBean getAdmin() {
		return admin;
	}

	public ArrayList<LoginBean> getAdminList() {
		return adminList;
	}
	
	public CustomerBean getUser() {
		return user;
	}

	public ArrayList<CustomerBean> getUserList() {
		return userList;
	}



	// Setters
	public void setAdmin(LoginBean admin) {
		this.admin = admin;
	}

	public void setAdminList(ArrayList<LoginBean> adminList) {
		this.adminList = adminList;
	}
	
	public void setUser(CustomerBean user) {
		this.user = user;
	}

	public void setUserList(ArrayList<CustomerBean> UserList) {
		this.userList = userList;
	}


	

	
	// Clear all values
	public void clear() {
		admin = null;
	}
	
	// toString

	@Override
	public String toString() {
		return "composite" + admin + adminList;
	}


	
}
