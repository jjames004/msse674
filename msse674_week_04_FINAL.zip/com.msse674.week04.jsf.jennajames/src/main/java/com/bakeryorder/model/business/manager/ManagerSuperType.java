package com.bakeryorder.model.business.manager;

import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.business.exception.PropertyFileNotFoundException;
import com.bakeryorder.model.services.manager.PropertyManager;


// from MSSE672 sample code
// DO NOT CHANGE

public abstract class ManagerSuperType {
	
	
		static
		{
	    	try
			{
	    		ManagerSuperType.loadProperties();  
			}
	    	catch (PropertyFileNotFoundException propertyFileNotFoundException)
			{
	    	   System.out.println ("Application Properties failed to be loaded - Application exiting...");
	    	   System.exit(1); // since we can't load the properties and this being crucial we'll exit the application!
			}				
		} // end of static initializer block
		
		// generic method for clients
		public abstract boolean performAction(String commandString, Composite composite); 
		
		
		// load property file
		
	    public static void loadProperties () throws PropertyFileNotFoundException {
	    	
	    	// get file location
	    	// set VM arguments for Controller in Run Configurations...
	    	
			String propertyFileLocation = System.getProperty("prop_location");
			
	        if (propertyFileLocation != null)
	        { 
	          // load via the property manager class
	          PropertyManager.loadProperties(propertyFileLocation);
	        }
	        else
	        {
	          System.out.println("Property file location not set. Passed in value is: " + propertyFileLocation + ".");
	          throw new PropertyFileNotFoundException ("Property file location not set", null);         
	        }
	    		
		} //end loadProperties



	    

}  // end ManagerSuperType
