/* CakeBean */

USE msse674_week_04;

CREATE TABLE cake_record (
cake_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
cake_flavor VARCHAR(100), 
cake_filling VARCHAR(100), 
cake_icing VARCHAR(100), 
cake_tiers VARCHAR(1), 
cake_decor VARCHAR(100));

INSERT INTO cake_record (
cake_flavor, 
cake_filling, 
cake_icing, 
cake_tiers, 
cake_decor) 
VALUES ('chocolate', 'strawberry', 'buttercream', '3', 'flowers');

INSERT INTO cake_record (
cake_flavor, 
cake_filling, 
cake_icing, 
cake_tiers, 
cake_decor) 
VALUES ('red velvet', 'blueberry', 'vanilla', '2', 'roses');
