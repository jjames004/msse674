/* CustomerBean */

USE msse674_week_04;

CREATE TABLE customer_record (
customer_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
customer_name VARCHAR(100), 
customer_email VARCHAR(50), 
customer_password VARCHAR(20), 
customer_gender VARCHAR(1), 
customer_address VARCHAR(100));

INSERT INTO customer_record (
customer_name, 
customer_email, 
customer_password, 
customer_gender, 
customer_address) 
VALUES ('joe dirt', 'joedirt@aol.com', 'password', 'M', 'America');

INSERT INTO customer_record (
customer_name, 
customer_email, 
customer_password, 
customer_gender, 
customer_address) 
VALUES ('peggy hill', 'peggyhill@aol.com', 'password', 'F', 'Texas');
