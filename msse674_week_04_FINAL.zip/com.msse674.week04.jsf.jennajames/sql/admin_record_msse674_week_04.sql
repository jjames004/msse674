/* Login and adminBean share this table */

/* LoginBean */

USE msse674_week_04;

CREATE TABLE admin_record (
admin_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
admin_name VARCHAR(100), 
admin_email VARCHAR(50), 
admin_password VARCHAR(20), 
admin_gender VARCHAR(1), 
admin_address VARCHAR(100));

INSERT INTO admin_record (
admin_name, 
admin_email, 
admin_password, 
admin_gender, 
admin_address) 
VALUES ('xuy', 'xuy@aol.com', 'pass', 'M', 'America');

INSERT INTO admin_record (
admin_name, 
admin_email, 
admin_password, 
admin_gender, 
admin_address) 
VALUES ('jenna', 'jenna@aol.com', 'pass', 'F', 'Colorado');
