package net.codejava;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.annotation.Rollback;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class UserRepositoryTests {

	@Autowired
	private TestEntityManager entityManager;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private RoleRepository roleRepo;
	
	
	@Test
	public void testCreateUser() {
		User user = new User();
		user.setEmail("hellokitty@aol.com");
		user.setPassword("password");
		user.setUsername("hellokitty");
		
		
		User savedUser = userRepo.save(user);
		
		User existUser = entityManager.find(User.class, savedUser.getId());
		
		assertThat(user.getEmail()).isEqualTo(existUser.getEmail());
		
	}
	
	@Test
	public void testAddRoleToNewUser() {
		Role roleAdmin = roleRepo.findByName("USER");
		
		User user = new User();
		user.setEmail("joedirt@gmail.com");
		user.setPassword("password");
		user.setUsername("joe");
		user.addRole(roleAdmin);		
		
		User savedUser = userRepo.save(user);
		
		assertThat(savedUser.getRoles().size()).isEqualTo(1);
	}
	
	// will require second run
	@Test
	public void testAddRoleToExistingUser() {
		String uname = "patrick";
		User user = userRepo.getUserByUsername(uname);
		Role roleCreator = roleRepo.findByName("CREATOR");
		
		user.addRole(roleCreator);
		
		User savedUser = userRepo.save(user);
		
		assertThat(savedUser.getRoles().size()).isEqualTo(2);	
	}
	
	@Test
	public void testFindByEmail() {
		String uname = "jenna";
		User user = userRepo.getUserByUsername(uname);
		
		assertThat(user.getUsername()).isEqualTo(uname);
	}
}
