package net.codejava;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cakes")
public class Cake {
	
	@Id
	@Column(name = "cake_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String flavor;
	private String frosting;
	private String decorations;
	private float price;

	protected Cake() {
	}

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}



	public String getFlavor() {
		return flavor;
	}


	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}


	public String getFrosting() {
		return frosting;
	}


	public void setFrosting(String frosting) {
		this.frosting = frosting;
	}


	public String getDecorations() {
		return decorations;
	}


	public void setDecorations(String decorations) {
		this.decorations = decorations;
	}


	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

}
