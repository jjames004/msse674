INSERT INTO `users` (`username`, `password`, `email`, `enabled`) VALUES ('patrick', '$2a$10$/73iY89cj6j8FPN85jUVdemRPH31HUntpoEvEPZKGlUuIDEd1.6Wu', 'patrick@aol.com', '1');
INSERT INTO `users` (`username`, `password`, `email`, `enabled`) VALUES ('alex', '$2a$10$/73iY89cj6j8FPN85jUVdemRPH31HUntpoEvEPZKGlUuIDEd1.6Wu', 'alex@aol.com', '1');
INSERT INTO `users` (`username`, `password`, `email`, `enabled`) VALUES ('john', '$2a$10$/73iY89cj6j8FPN85jUVdemRPH31HUntpoEvEPZKGlUuIDEd1.6Wu', 'john@aol.com', '1');
INSERT INTO `users` (`username`, `password`, `email`, `enabled`) VALUES ('jenna', '$2a$10$/73iY89cj6j8FPN85jUVdemRPH31HUntpoEvEPZKGlUuIDEd1.6Wu', 'jenna@aol.com', '1');
INSERT INTO `users` (`username`, `password`, `email`, `enabled`) VALUES ('admin', '$2a$10$/73iY89cj6j8FPN85jUVdemRPH31HUntpoEvEPZKGlUuIDEd1.6Wu', 'admin@aol.com', '1');
