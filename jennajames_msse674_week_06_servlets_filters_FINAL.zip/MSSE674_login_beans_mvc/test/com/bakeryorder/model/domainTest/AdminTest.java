package com.bakeryorder.model.domainTest;

import static org.junit.Assert.*;
import org.junit.Test;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.bakeryorder.model.domain.Admin;


class AdminTest {

	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(AdminTest.class.getName());
	
	Admin admin1 = new Admin(100, "Joe", "Dirt", "joedirt@gmail.com"); 
	
    Admin admin2 = new Admin(200, "Peggy", "Hill", "peggyhill@gmail.com");

    @Test
	void testEqualAdmin() {
		
		// calling the override equals method
		LOGGER.info("Test equal method override: " + admin1.equals(admin2));
		
		if(admin1.equals(admin2)) {
			LOGGER.error("The customer objects are equal!");
		} else {
			LOGGER.info("The customer objects are NOT equal!");
		}
	}
    
    @Test
	void testValidateCustomer() {
    	assertNotNull(admin2.getId());
    	assertNotNull(admin2.getFullname());
    	assertNotNull(admin2.getPassword());
    	assertNotNull(admin2.getEmail());
    }

}
