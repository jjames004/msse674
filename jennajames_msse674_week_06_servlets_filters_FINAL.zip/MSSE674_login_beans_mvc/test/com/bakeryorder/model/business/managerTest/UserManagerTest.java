package com.bakeryorder.model.business.managerTest;

import org.junit.jupiter.api.Test;
import junit.framework.TestCase;

import com.bakeryorder.model.business.manager.UserManager;
import com.bakeryorder.model.business.manager.ManagerSuperType;
import com.bakeryorder.model.business.exception.ServiceLoadException;
import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.User;
import com.bakeryorder.model.services.exception.UserException;
import com.bakeryorder.model.services.factory.SvcFactory;

class UserManagerTest extends TestCase {
	
	private SvcFactory svcFactory;
	private User user;
	private UserManager userMgr;
	private int id; 
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();

		svcFactory = new SvcFactory();

		// create instance of Customer class
		User user1 = new User(100, "Joe Dirt", "joedirt@gmail.com", "password"); 
		
		id = user1.getId();

	}
		

	@Test
	void testCreateUser() 
			throws ServiceLoadException, UserException {
		
			try {
				assertTrue(ManagerSuperType.class.isAssignableFrom(UserManager.class));
		  	    assertTrue(UserManager.createUser(user));
		        System.out.println("testCreateUser PASSED");	  	    
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				System.out.println("Test complete!");
			}
	}
		
	@Test
	void testGetUser()
			throws ServiceLoadException, UserException {
		
		try {
			assertTrue(ManagerSuperType.class.isAssignableFrom(UserManager.class));
	  	    System.out.println(UserManager.getUser(id));
	        System.out.println("testGetUser PASSED");	  	    
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("Test complete!");
		}
	}
}