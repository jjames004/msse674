package com.bakeryorder.model.services.manager;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.bakeryorder.model.business.exception.PropertyFileNotFoundException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


// direct copy from MSSE672 sample code
//DO NOT CHANGE

public class PropertyManager {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(PropertyManager.class.getName());
	
	private static Properties properties;
	 
	// load the appropriate property file for a given service
	
	public static void loadProperties(String propertyFileLocation) throws PropertyFileNotFoundException
	{
	    properties = new Properties();
	    FileInputStream sf = null;
	    try
	    {
	      sf = new FileInputStream(propertyFileLocation);
	      properties.load(sf);
	      
	      // print PropertyManager details to console
	      LOGGER.info("PropertyManager: Property file successfully loaded from location: " + propertyFileLocation);
	      LOGGER.info("PropertyManager: Property Contents: " + properties.toString());

	    }
	    catch (FileNotFoundException fnfe) 
		 {
	    	LOGGER.error("Property file not found.");
	    	throw new PropertyFileNotFoundException ("Property File cannot be found.", fnfe);
		 }
	    catch (IOException ioe) 
	    {
	    	LOGGER.error("IOException while loading Properties file.");
	    	throw new PropertyFileNotFoundException ("IOException while loading Properties file.", ioe);	    	
	    }
	    catch (Exception excp) 
	    {
	    	LOGGER.error("Exception while loading Properties file.");
	    	throw new PropertyFileNotFoundException ("Exception while loading Properties file.", excp);	    	
	    }
		finally
		{
			if (sf != null)
			{	
			   try {
 			    sf.close();
			   } catch (IOException e) {
				e.printStackTrace();
			   }
		    }	
		}	    
	} //end loadProperties()

    static public String getPropertyValue (String key)
    {
 
    	return properties.getProperty(key);
    }

}
