package com.bakeryorder.model.domain;
import java.util.ArrayList;

public class AdminComposite {
	
	// create an instance of each domain object
	private Admin admin;
	private User user;
	
	private ArrayList<Admin> adminList;
	private ArrayList<User> userList;
	
	// Constructor
	public AdminComposite() {
	}

	// Getters
	public Admin getAdmin() {
		return admin;
	}

	public ArrayList<Admin> getAdminList() {
		return adminList;
	}
	
	public User getUser() {
		return user;
	}

	public ArrayList<User> getUserList() {
		return userList;
	}



	// Setters
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public void setAdminList(ArrayList<Admin> adminList) {
		this.adminList = adminList;
	}
	
	public void setUser(User user) {
		this.user = user;
	}

	public void setUserList(ArrayList<User> UserList) {
		this.userList = userList;
	}


	

	
	// Clear all values
	public void clear() {
		admin = null;
	}
	
	// toString

	@Override
	public String toString() {
		return "composite" + admin + adminList;
	}


	
}
