package com.bakeryorder.model.integration.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bakeryorder.model.domain.Cake;

/**
 * AbstractDAO.java This DAO class provides CRUD database operations for the
 * table cakes in the database.
 * 
 *
 */
public class CakeDAO {
//	String jdbcURL = "jdbc:mysql://jennajames-msse674.chem6ns37jb0.us-west-1.rds.amazonaws.com:3306/jennajames_msse674?user=jenna&password=Z0obaby3";
//	String dbUser = "jenna";
//	String dbPassword = "Z0obaby3";
	
//	local mysql instance
	String jdbcURL = "jdbc:mysql://localhost:3306/jennajames_msse674";
	String dbUser = "root";
	String dbPassword = "Z0obaby3";

	private static final String INSERT_CAKES_SQL = "INSERT INTO cakes" + "  (email, flavor, cakename) VALUES "
			+ " (?, ?, ?);";

	private static final String SELECT_CAKE_BY_ID = "select id,email,flavor, cakename from cakes where id =?";
	private static final String SELECT_ALL_CAKES = "select * from cakes";
	private static final String DELETE_CAKES_SQL = "delete from cakes where id = ?;";
	private static final String UPDATE_CAKES_SQL = "update cakes set email = ?,flavor= ?, cakename =? where id = ?;";

	public CakeDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertCake(Cake cake) throws SQLException {
		System.out.println(INSERT_CAKES_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CAKES_SQL)) {
			preparedStatement.setString(1, cake.getEmail());
			preparedStatement.setString(2, cake.getFlavor());
			preparedStatement.setString(3, cake.getCakename());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Cake selectCake(int id) {
		Cake cake = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_CAKE_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				
				String email = rs.getString("email");
				String flavor = rs.getString("flavor");
				String cakename = rs.getString("cakename");
				cake = new Cake(id, email, flavor, cakename);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return cake;
	}

	public List<Cake> selectAllCakes() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Cake> cakes = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_CAKES);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				
				String email = rs.getString("email");
				String flavor = rs.getString("flavor");
				String cakename = rs.getString("cakename");
				cakes.add(new Cake(id, email, flavor, cakename));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return cakes;
	}

	public boolean deleteCake(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_CAKES_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateCake(Cake cake) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_CAKES_SQL);) {
			statement.setString(1, cake.getEmail());
			statement.setString(2, cake.getFlavor());
			statement.setString(3, cake.getCakename());
			statement.setInt(4, cake.getId());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}

}
