package com.bakeryorder.model.business.manager;

import com.bakeryorder.model.business.exception.*;
import com.bakeryorder.model.domain.*;
import com.bakeryorder.model.services.factory.SvcFactory;
import com.bakeryorder.model.services.cakeservice.ICakeService;
import com.bakeryorder.model.services.exception.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CakeManager extends ManagerSuperType {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CakeManager.class.getName());

	private static CakeManager myInstance;

	// constructor
	private CakeManager() {
	}

	// create only one Cake Manager
	public static synchronized CakeManager getInstance() {
		if (myInstance == null) {
			myInstance = new CakeManager();
		}
		return myInstance;
	}

	// generic method
	@Override
	public boolean performAction(String commandString, Composite composite) {
		// TODO Auto-generated method stub
		return false;
	}

	private boolean createUser(String commandString, Composite composite) {
			boolean isAdded = false;
	
		SvcFactory svcFactory = SvcFactory.getInstance();
		ICakeService cakeService;
	
		try {
			cakeService = (ICakeService) svcFactory.getService(commandString);
			isAdded = cakeService.createCake(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("CakeManager::failed to load Cake Service.");																			
		} catch (CakeException re) {
			LOGGER.error("CakeManager::createCake() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("CakeManager::Unknown error."); 
		}
	
		return isAdded;
	}
	
	private boolean readUser(String commandString, Composite composite) {
		boolean isUpdated = false;
		
		SvcFactory svcFactory = SvcFactory.getInstance();
		ICakeService cakeService;
	
		try {
			cakeService = (ICakeService) svcFactory.getService(commandString);
			isUpdated = cakeService.updateCake(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("CakeManager::failed to load Cake Service.");																			
		} catch (CakeException re) {
			LOGGER.error("CakeManager::readCake() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("ERROR: CakeManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private boolean updateUser(String commandString, Composite composite) {
			boolean isUpdated = false;
			
		SvcFactory svcFactory = SvcFactory.getInstance();
		ICakeService cakeService;
	
		try {
			cakeService = (ICakeService) svcFactory.getService(commandString);
			isUpdated = cakeService.updateCake(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("CakeManager::failed to load Cake Service.");																			
		} catch (CakeException re) {
			LOGGER.error("CakeManager::updateCake() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("ERROR: CakeManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private boolean deleteCake(String commandString, Composite composite) {
		boolean isUpdated = false;
		
	SvcFactory svcFactory = SvcFactory.getInstance();
	ICakeService cakeService;

	try {
		cakeService = (ICakeService) svcFactory.getService(commandString);
		isUpdated = cakeService.deleteCake(composite);
	} catch (ServiceLoadException e1) {
		LOGGER.error("CakeManager::failed to load Cake Service.");																			
	} catch (CakeException re) {
		LOGGER.error("CakeManager::deleteCake() failed"); 
		re.printStackTrace();
	} catch (Exception ex) {
		LOGGER.error("ERROR: CakeManager::Unknown error."); 
	}

	return isUpdated;
}

// for testing
	public static boolean createCake(Cake cake) {
		Cake c1 = new Cake("cake@gmail.com", "chocolate", "the best cake name");
		return false;
	}

	public static char[] getCake(int id) {
		Cake c1 = new Cake("cake@gmail.com", "chocolate", "the best cake name");
		return null;
	}


	
	

} // end CakeLoginManager class
