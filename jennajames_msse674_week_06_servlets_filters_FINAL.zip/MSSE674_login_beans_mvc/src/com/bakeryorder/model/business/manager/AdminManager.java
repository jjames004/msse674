package com.bakeryorder.model.business.manager;

import com.bakeryorder.model.business.exception.*;
import com.bakeryorder.model.domain.*;
import com.bakeryorder.model.services.factory.SvcFactory;
import com.bakeryorder.model.services.adminservice.IAdminService;
import com.bakeryorder.model.services.exception.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AdminManager extends ManagerSuperType {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(AdminManager.class.getName());

	private static AdminManager myInstance;

	// constructor
	private AdminManager() {
	}

	// create only one User Manager
	public static synchronized AdminManager getInstance() {
		if (myInstance == null) {
			myInstance = new AdminManager();
		}
		return myInstance;
	}

	// generic method
	@Override
	public boolean performAction(String commandString, Composite composite) {
		// TODO Auto-generated method stub
		return false;
	}

	private boolean createUser(String commandString, AdminComposite composite) {
			boolean isAdded = false;
	
		SvcFactory svcFactory = SvcFactory.getInstance();
		IAdminService adminService;
	
		try {
			adminService = (IAdminService) svcFactory.getService(commandString);
			isAdded = adminService.createUser(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("AdminManager::failed to load Admin Service.");																			
		} catch (AdminException re) {
			LOGGER.error("AdminManager::createAdmin() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("AdminManager::Unknown error."); 
		}
	
		return isAdded;
	}
	
	private boolean readUser(String commandString, AdminComposite composite) {
		boolean isUpdated = false;
		
		SvcFactory svcFactory = SvcFactory.getInstance();
		IAdminService adminService;
	
		try {
			adminService = (IAdminService) svcFactory.getService(commandString);
			isUpdated = adminService.updateUser(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("AdminManager::failed to load Admin Service.");																			
		} catch (AdminException re) {
			LOGGER.error("AdminManager::readAdmin() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("ERROR: adminManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private boolean updateUser(String commandString, AdminComposite composite) {
			boolean isUpdated = false;
			
		SvcFactory svcFactory = SvcFactory.getInstance();
		IAdminService adminService;
	
		try {
			adminService = (IAdminService) svcFactory.getService(commandString);
			isUpdated = adminService.updateUser(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("AdminManager::failed to load Admin Service.");																			
		} catch (AdminException re) {
			LOGGER.error("AdminManager::updateAdmin() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("ERROR: adminManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private boolean deleteUser(String commandString, AdminComposite composite) {
		boolean isUpdated = false;
		
	SvcFactory svcFactory = SvcFactory.getInstance();
	IAdminService adminService;

	try {
		adminService = (IAdminService) svcFactory.getService(commandString);
		isUpdated = adminService.deleteUser(composite);
	} catch (ServiceLoadException e1) {
		LOGGER.error("AdminManager::failed to load Admin Service.");																			
	} catch (AdminException re) {
		LOGGER.error("AdminManager::deleteAdmin() failed"); 
		re.printStackTrace();
	} catch (Exception ex) {
		LOGGER.error("ERROR: adminManager::Unknown error."); 
	}

	return isUpdated;
}


// for testing
	public static boolean createAdmin(Admin admin) {
		Admin a1 = new Admin(100, "Joe Dirt", "joedirt@gmail.com", "password");
		return true;
	}

	public static int getAdmin(int id) {
		Admin a1 = new Admin(100, "Joe Dirt", "joedirt@gmail.com", "password");
		return a1.getId();
	}




	
	

} // end UserLoginManager class
