package com.bakeryorder.filters;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

// The MainLog is a simple class where we add logs entries 
// and then return them in the body response, 
// so we will be able to see by where our request has gone.

@Component
@Scope(value=org.springframework.web.context.WebApplicationContext.SCOPE_REQUEST,proxyMode=ScopedProxyMode.TARGET_CLASS)
public class MainLog {
	
	// log4j2
	// static class-named logger
	private static final Logger log = LoggerFactory.getLogger(MainLog.class);

	int sequence;
	String uuid;
	String message;
	
	// MainLog constructor
	// setup a unique identifier and output to a string
	// define the message field
	// set the sequence to 1
	public MainLog() {
		uuid=UUID.randomUUID().toString();
		message="";
		sequence=1;
	}
	
	// called in the FilterController
	// accepts a string msg as an argument
	/* unique identifier and incremented sequence are 
	 * printed to the console
	 */
	// argument value is passed to the class field
	
	public void debug(String msg) {
		msg="MainLog: "+uuid+"/"+sequence+" "+msg;
		
		System.out.println(msg);
		sequence++;
		message+=msg+"\n\r";
	}
	
	/* returns the values attributed to the 
	 *class field in the debug() method
	 */
	public String getMessage()	{
		return message;
	}
	
	// reset the sequence for the next request
	public void resetSequence() {
		sequence=1;
		message="";
	}
}
