package com.bakeryorder.filters;

import java.io.IOException;

// imports Filter, ServletRequest, ServletResponse, FilterChain, and ServletException
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;


// @Component is an annotation that allows us to register the class as a bean in the ApplicationContext
@Component

// specify order of the filter
// the MyFilter filter will run before the OtherFilter filter and so on...
@Order(1)

// implements Filter interface tells Spring how this class should be used when register via @Component
// MyFilter class performs different actions depending on the URL called
public class MyFilter implements Filter{
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(MyFilter.class.getName());

	@Autowired
	MainLog mainLog;
	
	// We will be able to see the content of the HTTP request in the ServletRequest object 
	// and we can modify the answer in the ServletResponse object. 
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest=null;
		
		httpRequest= (HttpServletRequest) request;
		HttpServletResponse  myResponse= (HttpServletResponse) response;
		mainLog.debug("MyFilter: URL"
				+ " called: "+httpRequest.getRequestURL().toString());

		
		if (httpRequest.getRequestURL().toString().endsWith("/login"))	{			
			myResponse.addHeader("JENNA", "FILTERED");						
			chain.doFilter(httpRequest, myResponse);
			LOGGER.info("MyFilter: Request Remote Host:"+request.getRemoteHost());
			LOGGER.info("MyFilter: Request Remote Address:"+request.getRemoteAddr());
			LOGGER.info("MyFilter: Response Content Type is: " + response.getContentType());
			LOGGER.info("MyFilter: Response Character Type is: " + response.getCharacterEncoding());
			return;
		}
		if (httpRequest.getRequestURL().toString().endsWith("/redirect"))	{			
			myResponse.addHeader("JENNA", "REDIRECTED");
			myResponse.sendRedirect("redirected");
			chain.doFilter(httpRequest, myResponse);
			return;
		}
        if (httpRequest.getRequestURL().toString().endsWith("/none"))	{   
            myResponse.setStatus(HttpStatus.BAD_GATEWAY.value());
            myResponse.getOutputStream().flush();
            myResponse.getOutputStream().println("-- I don't have any to tell you --");
            return; // i have nothing
                }
		if (httpRequest.getRequestURL().toString().endsWith("/cancel"))	{			
			myResponse.addHeader("JENNA", "CANCEL");
			myResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			myResponse.getOutputStream().flush();
			myResponse.getOutputStream().println("-- Output by filter error --");
			chain.doFilter(httpRequest, myResponse);
			LOGGER.info("MyFilter: Response Content Type is: " + response.getContentType());
			LOGGER.info("MyFilter: Response Character Type is: " + response.getCharacterEncoding());
			return;
		}

		// tells spring how to continue handling the request
		// pass it in the chain
		chain.doFilter(request, response);
	}
	
	// this method will be called by container while deployment
    public void init(FilterConfig config) throws ServletException {

    	LOGGER.info("Filter name is "+config.getFilterName());
    	LOGGER.info("ServletContext name is"+config.getServletContext());
    }
    
    public void destroy() {
    	LOGGER.info("destroy() method has been get invoked");

    }

}
