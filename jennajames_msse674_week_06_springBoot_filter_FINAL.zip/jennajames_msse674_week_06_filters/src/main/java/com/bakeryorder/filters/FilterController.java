package com.bakeryorder.filters;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


// controller and listening REST requests in this class

@RestController
public class FilterController {
	@Autowired
	MainLog mainLog;
	
	// all requests must meet a specific requirement
	// they must have a specific header
	
	// The entryOrderfunction will capture all GET requests, which the 
	// URIs aren't defined in the program
	
	// http://localhost:8080/anything
	@GetMapping("*")
	public String entryOther(HttpServletRequest request,HttpServletResponse response)
	{	
		mainLog.debug("In entryOther");
		if (response.getHeader("CAKE")!=null)
			mainLog.debug("Header contains CAKE: "+response.getHeader("CAKE"));
		if (response.getHeader("PRODUCT")!=null)
			mainLog.debug("Header contains PRODUCT: "+response.getHeader("PRODUCT"));
		if (response.getHeader("USER")!=null)
			mainLog.debug("Header contains USER: "+response.getHeader("USER"));
		if (response.getHeader("JENNA")!=null)
			mainLog.debug("Header contains JENNA: "+response.getHeader("JENNA"));
		
		return "returning by function entryOther\r\n"+
				mainLog.getMessage();
	}
	
	// The entryOne function will be processing the GET requests 
	// to http://localhost:8080/login or http://localhost:8080/ or http://localhost:8080/one
	// MyFilter.java
	@GetMapping(value={"/","login"})
	public String entryOne(HttpServletRequest request,HttpServletResponse response	)
	{
		mainLog.debug("In entryOne");
		if (response.getHeader("JENNA")!=null)
		{
			mainLog.debug("Header contains JENNA: "+response.getHeader("JENNA"));
			return entryTwo(response);				
		}
		return "returning by function entryOne\r\n"+
				mainLog.getMessage();
	}
	
	
	// http://localhost:8080/register
	// OtherFilter.java
	@GetMapping("register")
	public String entryTwo(HttpServletResponse response)
	{
		mainLog.debug("In entryTwo");
		if (response.getHeader("JENNA")!=null)
			mainLog.debug("Header contains JENNA: "+response.getHeader("JENNA"));
		return "returning by function entryTwo\r\n"+
				mainLog.getMessage();
	}
	
	// http://localhost:8080/users
	@GetMapping("users")
	public String entryThree()
	{
		mainLog.debug("In entryThree");
		return "returning by function entryThree\n"+
				mainLog.getMessage();
	}
	
	// http://localhost:8080/redirect
	@GetMapping("redirected")
	public String entryRedirect(HttpServletRequest request)
	{
		mainLog.debug("In redirected");
		return "returning by function entryRedirect\n"+
				mainLog.getMessage();
	}
}
