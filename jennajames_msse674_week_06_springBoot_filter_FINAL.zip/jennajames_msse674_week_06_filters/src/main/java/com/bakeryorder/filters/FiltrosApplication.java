package com.bakeryorder.filters;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class FiltrosApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(FiltrosApplication.class, args);
	}
	
	
	// Filter With URL Patterns
	// remove the @Component annotation from the filter class 
	// definition and register the filter using a FilterRegistrationBean
	@Bean
	public FilterRegistrationBean<ProductsFilter> productsFilter()
	{
		FilterRegistrationBean<ProductsFilter> registrationBean1 = new FilterRegistrationBean<>();				
		registrationBean1.setFilter(new ProductsFilter());
		registrationBean1.addUrlPatterns("/newProduct/*");
		return registrationBean1;
	}
	
	@Bean
	public FilterRegistrationBean<UsersFilter> usersFilter()
	{
		FilterRegistrationBean<UsersFilter> registrationBean2 = new FilterRegistrationBean<>();				
		registrationBean2.setFilter(new UsersFilter());
		registrationBean2.addUrlPatterns("/newUser/*");
		return registrationBean2;
	}
	
	@Bean
	public FilterRegistrationBean<CakesFilter> cakesFilter()
	{
		FilterRegistrationBean<CakesFilter> registrationBean = new FilterRegistrationBean<>();				
		registrationBean.setFilter(new CakesFilter());
		registrationBean.addUrlPatterns("/newCake/*");
		return registrationBean;
	}
}
