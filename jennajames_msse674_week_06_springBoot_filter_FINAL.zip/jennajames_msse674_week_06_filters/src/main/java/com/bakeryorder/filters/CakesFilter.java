package com.bakeryorder.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.annotation.Order;

// remove the @Component annotation from the filter class 
// definition and register the filter using a FilterRegistrationBean
@Order(3)
public class CakesFilter implements Filter{	
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(CakesFilter.class.getName());
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {		
		HttpServletResponse  myResponse= (HttpServletResponse) response;
		myResponse.addHeader("CAKE", "CREATE");	
		chain.doFilter(request, response);
	}
	
	// this method will be called by container while deployment
    public void init(FilterConfig config) throws ServletException {

        LOGGER.info("Filter name is "+config.getFilterName());
        LOGGER.info("ServletContext name is"+config.getServletContext());
    }
    
    public void destroy() {
    	LOGGER.info("destroy() method has been get invoked");

    }

}
