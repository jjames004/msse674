package com.bakeryorder.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;


@Component
@Order(2)

// OtherFilter only adds a log when it is executed
public class OtherFilter implements Filter {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(OtherFilter.class.getName());

	@Autowired
	MainLog mainLog;
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest=null;
		
		httpRequest= (HttpServletRequest) request;
		HttpServletResponse  myResponse= (HttpServletResponse) response;
		mainLog.debug("OtherFilter: URL"
				+ " called: "+httpRequest.getRequestURL().toString());
		
		if (myResponse.getHeader("JENNA")!=null)
			mainLog.debug("OtherFilter: Header contains JENNA: "+myResponse.getHeader("JENNA"));		

		chain.doFilter(request, response);
	}
	
	// this method will be called by container while deployment
    public void init(FilterConfig config) throws ServletException {

        
    	LOGGER.info("Filter name is "+config.getFilterName());
    	LOGGER.info("ServletContext name is"+config.getServletContext());
    }
    
    public void destroy() {
    	LOGGER.info("destroy() method has been get invoked");

    }

}
