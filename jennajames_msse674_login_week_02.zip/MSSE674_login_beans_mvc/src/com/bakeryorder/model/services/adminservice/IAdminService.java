package com.bakeryorder.model.services.adminservice;

import com.bakeryorder.model.domain.AdminComposite;
import com.bakeryorder.model.services.IService;
import com.bakeryorder.model.services.exception.AdminException;

public interface IAdminService extends IService {
	
	public final String NAME = "IAdminService";
	
	// list the methods available through the specific interface
	// each method accepts an instance of the composite class
	
	public boolean createCredentials(AdminComposite composite) throws AdminException;
	public boolean readCredentials(AdminComposite composite) throws AdminException;
	public boolean updateCredentials(AdminComposite composite) throws AdminException;
	public boolean deleteCredentials(AdminComposite composite) throws AdminException;

}
