package com.bakeryorder.model.services.adminservice;

import java.util.ArrayList;

import com.bakeryorder.model.domain.Admin;
import com.bakeryorder.model.domain.AdminComposite;
import com.bakeryorder.model.services.exception.AdminException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AdminServiceImpl implements IAdminService {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(AdminServiceImpl.class.getName());

	@Override
	public boolean createCredentials(AdminComposite composite) throws AdminException {
		LOGGER.info("AdminServiceImpl::createCredentials().");
		boolean isSuccess = false;
		
		try {
			Admin newLogin = composite.getAdmin();
			isSuccess = true;
		} catch (Exception ex){
			throw new AdminException("ERROR:  There was a problem with the AdminService.", ex);
		} 
		return isSuccess;
	}
	
	@Override
	public boolean readCredentials(AdminComposite composite) throws AdminException {
		LOGGER.info("AdminServiceImpl::readCredentials().");
		boolean isSuccess = false;
		
		try {
			Admin newLogin = composite.getAdmin();
			isSuccess = true;
		} catch (Exception ex){
			throw new AdminException("ERROR:  There was a problem with the AdminService.", ex);
		} 
		return isSuccess;
	}

	@Override
	public boolean updateCredentials(AdminComposite composite) throws AdminException {
		LOGGER.info("INFO: AdminServiceImpl::updateCredentials().");
		boolean isSuccess = false;
		
		try {
			Admin anotherLogin = composite.getAdmin();
			isSuccess = true;
		} catch (Exception ex){
			throw new AdminException("ERROR:  There was a problem with the AdminService.", ex);
		} 
		return isSuccess;
	}

	

	@Override
	public boolean deleteCredentials(AdminComposite composite) throws AdminException {
		LOGGER.info("INFO: AdminServiceImpl::deleteCredentials().");
		boolean isSuccess = false;
		
		try {
			Admin logout = composite.getAdmin();
			isSuccess = true;
		} catch (Exception ex){
			throw new AdminException("ERROR:  There was a problem with the AdminService.", ex);
		} 
		return isSuccess;
	}


}
