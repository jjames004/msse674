package com.bakeryorder.model.services.userservice;

import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.services.IService;
import com.bakeryorder.model.services.exception.UserException;

public interface IUserService extends IService {
	
	public final String NAME = "IUserService";
	
	// list the methods available through the specific interface
	// each method accepts an instance of the composite class
	
	public boolean createCredentials(Composite composite) throws UserException;
	public boolean readCredentials(Composite composite) throws UserException;
	public boolean updateCredentials(Composite composite) throws UserException;
	public boolean deleteCredentials(Composite composite) throws UserException;

}
