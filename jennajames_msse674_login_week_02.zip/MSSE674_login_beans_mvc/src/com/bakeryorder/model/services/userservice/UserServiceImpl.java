package com.bakeryorder.model.services.userservice;

import java.util.ArrayList;

import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.User;
import com.bakeryorder.model.services.exception.UserException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class UserServiceImpl implements IUserService {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(UserServiceImpl.class.getName());

	@Override
	public boolean createCredentials(Composite composite) throws UserException {
		LOGGER.info("UserServiceImpl::createCredentials().");
		boolean isSuccess = false;
		
		try {
			User newLogin = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}
	
	@Override
	public boolean readCredentials(Composite composite) throws UserException {
		LOGGER.info("UserServiceImpl::readCredentials().");
		boolean isSuccess = false;
		
		try {
			User newLogin = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}

	@Override
	public boolean updateCredentials(Composite composite) throws UserException {
		LOGGER.info("INFO: UserServiceImpl::updateCredentials().");
		boolean isSuccess = false;
		
		try {
			User anotherLogin = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}

	

	@Override
	public boolean deleteCredentials(Composite composite) throws UserException {
		LOGGER.info("INFO: UserServiceImpl::deleteCredentials().");
		boolean isSuccess = false;
		
		try {
			User logout = composite.getUser();
			isSuccess = true;
		} catch (Exception ex){
			throw new UserException("ERROR:  There was a problem with the UserService.", ex);
		} 
		return isSuccess;
	}


}
