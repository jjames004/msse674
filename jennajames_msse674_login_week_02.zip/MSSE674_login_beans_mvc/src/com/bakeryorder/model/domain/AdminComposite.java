package com.bakeryorder.model.domain;
import java.util.ArrayList;

public class AdminComposite {
	
	// create an instance of each domain object
	private Admin admin;

	
	// associate multiple flights and reservations with a single customer
	private ArrayList<Admin> adminList;
	
	// Constructor
	public AdminComposite() {
	}

	// Getters
	public Admin getAdmin() {
		return admin;
	}




	public ArrayList<Admin> getAdminList() {
		return adminList;
	}



	// Setters
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}




	public void setAdminList(ArrayList<Admin> adminList) {
		this.adminList = adminList;
	}


	

	
	// Clear all values
	public void clear() {
		admin = null;
	}
	
	// toString

	@Override
	public String toString() {
		return "composite" + admin + adminList;
	}


	
}
