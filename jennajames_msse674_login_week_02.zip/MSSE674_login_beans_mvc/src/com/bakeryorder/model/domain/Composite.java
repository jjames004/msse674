package com.bakeryorder.model.domain;
import java.util.ArrayList;

public class Composite {
	
	// create an instance of each domain object
	private User user;

	
	// associate multiple flights and reservations with a single customer
	private ArrayList<User> userList;
	
	// Constructor
	public Composite() {
	}

	// Getters
	public User getUser() {
		return user;
	}




	public ArrayList<User> getUserList() {
		return userList;
	}



	// Setters
	public void setUser(User user) {
		this.user = user;
	}




	public void setUserList(ArrayList<User> userList) {
		this.userList = userList;
	}


	

	
	// Clear all values
	public void clear() {
		user = null;
	}
	
	// toString

	@Override
	public String toString() {
		return "composite" + user + userList;
	}


	
}
