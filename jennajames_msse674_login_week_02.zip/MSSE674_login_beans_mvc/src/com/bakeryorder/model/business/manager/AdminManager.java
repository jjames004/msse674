package com.bakeryorder.model.business.manager;

import com.bakeryorder.model.business.exception.*;
import com.bakeryorder.model.domain.*;
import com.bakeryorder.model.services.factory.SvcFactory;
import com.bakeryorder.model.services.adminservice.IAdminService;
import com.bakeryorder.model.services.exception.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AdminManager extends ManagerSuperType {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(AdminManager.class.getName());

	private static AdminManager myInstance;

	// constructor
	private AdminManager() {
	}

	// create only one User Manager
	public static synchronized AdminManager getInstance() {
		if (myInstance == null) {
			myInstance = new AdminManager();
		}
		return myInstance;
	}

	// generic method
//	@Override
//	public boolean performAction(String commandString, AdminComposite composite) {
//		boolean retVal = false;
//		
//		// the facades
//		if (commandString.equals("ADDCREDENTIALS")) {
//			retVal = createCredentials(IAdminService.NAME, composite);
//		} else {
//			 LOGGER.info("Add new workflows here.");
//		}
//
//		return retVal;
//	}

	private boolean createCredentials(String commandString, AdminComposite composite) {
			boolean isAdded = false;
	
		SvcFactory svcFactory = SvcFactory.getInstance();
		IAdminService loginService;
	
		try {
			loginService = (IAdminService) svcFactory.getService(commandString);
			isAdded = loginService.createCredentials(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("AdminLoginManager::failed to load Login Service.");																			
		} catch (AdminException re) {
			LOGGER.error("AdminLoginManager::createCredentials() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("AdminLoginManager::Unknown error."); 
		}
	
		return isAdded;
	}
	
	private boolean readCredentials(String commandString, AdminComposite composite) {
		boolean isUpdated = false;
		
		SvcFactory svcFactory = SvcFactory.getInstance();
		IAdminService loginService;
	
		try {
			loginService = (IAdminService) svcFactory.getService(commandString);
			isUpdated = loginService.updateCredentials(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("AdminLoginManager::failed to load Login Service.");																			
		} catch (AdminException re) {
			LOGGER.error("AdminLoginManager::readCredentials() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("ERROR: UserLoginManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private boolean updateCredentials(String commandString, AdminComposite composite) {
			boolean isUpdated = false;
			
		SvcFactory svcFactory = SvcFactory.getInstance();
		IAdminService loginService;
	
		try {
			loginService = (IAdminService) svcFactory.getService(commandString);
			isUpdated = loginService.updateCredentials(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("AdminLoginManager::failed to load Login Service.");																			
		} catch (AdminException re) {
			LOGGER.error("AdminLoginManager::updateCredentials() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("ERROR: UserLoginManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private boolean deleteCredentials(String commandString, AdminComposite composite) {
		boolean isUpdated = false;
		
	SvcFactory svcFactory = SvcFactory.getInstance();
	IAdminService loginService;

	try {
		loginService = (IAdminService) svcFactory.getService(commandString);
		isUpdated = loginService.updateCredentials(composite);
	} catch (ServiceLoadException e1) {
		LOGGER.error("AdminLoginManager::failed to load Login Service.");																			
	} catch (AdminException re) {
		LOGGER.error("AdminLoginManager::deleteCredentials() failed"); 
		re.printStackTrace();
	} catch (Exception ex) {
		LOGGER.error("ERROR: UserLoginManager::Unknown error."); 
	}

	return isUpdated;
}

	@Override
	public boolean performAction(String commandString, Composite composite) {
		// TODO Auto-generated method stub
		return false;
	}


	
	

} // end UserLoginManager class
