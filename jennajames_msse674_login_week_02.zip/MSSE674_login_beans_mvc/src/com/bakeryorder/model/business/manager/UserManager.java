package com.bakeryorder.model.business.manager;

import com.bakeryorder.model.business.exception.*;
import com.bakeryorder.model.domain.Composite;
import com.bakeryorder.model.domain.*;
import com.bakeryorder.model.services.factory.SvcFactory;
import com.bakeryorder.model.services.userservice.IUserService;
import com.bakeryorder.model.services.exception.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class UserManager extends ManagerSuperType {
	
	// static class-named logger
    private static final Logger LOGGER = LogManager.getLogger(UserManager.class.getName());

	private static UserManager myInstance;

	// constructor
	private UserManager() {
	}

	// create only one User Manager
	public static synchronized UserManager getInstance() {
		if (myInstance == null) {
			myInstance = new UserManager();
		}
		return myInstance;
	}

	// generic method
	@Override
	public boolean performAction(String commandString, Composite composite) {
		boolean retVal = false;
		
		// the facades
		if (commandString.equals("ADDCREDENTIALS")) {
			retVal = createCredentials(IUserService.NAME, composite);
		} else {
			 LOGGER.info("Add new workflows here.");
		}

		return retVal;
	}

	private boolean createCredentials(String commandString, Composite composite) {
			boolean isAdded = false;
	
		SvcFactory svcFactory = SvcFactory.getInstance();
		IUserService loginService;
	
		try {
			loginService = (IUserService) svcFactory.getService(commandString);
			isAdded = loginService.createCredentials(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("UserLoginManager::failed to load Login Service.");																			
		} catch (UserException re) {
			LOGGER.error("UserLoginManager::createCredentials() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("UserLoginManager::Unknown error."); 
		}
	
		return isAdded;
	}
	
	private boolean readCredentials(String commandString, Composite composite) {
		boolean isUpdated = false;
		
		SvcFactory svcFactory = SvcFactory.getInstance();
		IUserService loginService;
	
		try {
			loginService = (IUserService) svcFactory.getService(commandString);
			isUpdated = loginService.updateCredentials(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("UserLoginManager::failed to load Login Service.");																			
		} catch (UserException re) {
			LOGGER.error("UserLoginManager::readCredentials() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("ERROR: UserLoginManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private boolean updateCredentials(String commandString, Composite composite) {
			boolean isUpdated = false;
			
		SvcFactory svcFactory = SvcFactory.getInstance();
		IUserService loginService;
	
		try {
			loginService = (IUserService) svcFactory.getService(commandString);
			isUpdated = loginService.updateCredentials(composite);
		} catch (ServiceLoadException e1) {
			LOGGER.error("UserLoginManager::failed to load Login Service.");																			
		} catch (UserException re) {
			LOGGER.error("UserLoginManager::updateCredentials() failed"); 
			re.printStackTrace();
		} catch (Exception ex) {
			LOGGER.error("ERROR: UserLoginManager::Unknown error."); 
		}
	
		return isUpdated;
	}
	
	private boolean deleteCredentials(String commandString, Composite composite) {
		boolean isUpdated = false;
		
	SvcFactory svcFactory = SvcFactory.getInstance();
	IUserService loginService;

	try {
		loginService = (IUserService) svcFactory.getService(commandString);
		isUpdated = loginService.updateCredentials(composite);
	} catch (ServiceLoadException e1) {
		LOGGER.error("UserLoginManager::failed to load Login Service.");																			
	} catch (UserException re) {
		LOGGER.error("UserLoginManager::deleteCredentials() failed"); 
		re.printStackTrace();
	} catch (Exception ex) {
		LOGGER.error("ERROR: UserLoginManager::Unknown error."); 
	}

	return isUpdated;
}
	
	

} // end UserLoginManager class
