package com.bakeryorder.model.integration.jdbc;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.bakeryorder.model.domain.Admin;
import com.bakeryorder.model.domain.User;

public class AdminDAO {
	
	
    public Admin checkLogin(String email, String password) throws SQLException,
    ClassNotFoundException {
    	
//    	local mysql instance
//		String jdbcURL = "jdbc:mysql://localhost:3306/jennajames_msse674";
//		String dbUser = "root";
//		String dbPassword = "Z0obaby3";
		
//		AWS MySQL instance
//    	jdbc string format: jdbc:driver://hostname:port/dbName?user=userName&password=password
		String jdbcURL = "jdbc:mysql://jennajames-msse674.chem6ns37jb0.us-west-1.rds.amazonaws.com:3306/jennajames_msse674?user=jenna&password=Z0obaby3";
		String dbUser = "jenna";
		String dbPassword = "Z0obaby3";
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
		String sql = "SELECT * FROM admins WHERE email = ? and password = ?";
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, email);
		statement.setString(2, password);
		
		ResultSet result = statement.executeQuery();
		
		Admin admin = null;
		
		if (result.next()) {
			admin = new Admin();
		    admin.setFullname(result.getString("fullname"));
		    admin.setEmail(email);
		}
		
		connection.close();
		
		return admin;
	}

}
