package net.codejava;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CakeService {
	@Autowired
	private CakeRepository repo;
	
	public List<Cake> listAll() {		
		return repo.findAll();
	}
	
	public void save(Cake cake) {
		repo.save(cake);
	}
	
	public Cake get(Long id) {
		return repo.findById(id).get();
	}
	
	public void delete(Long id) {
		repo.deleteById(id);
	}
}
