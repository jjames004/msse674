package net.codejava;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {
	@Autowired
	private ProductService service;
	
	@Autowired
	private UserService service1;
	
	@Autowired
	private CakeService service2;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<Product> listProducts = service.listAll();
		model.addAttribute("listProducts", listProducts);
		
		List<User> listUsers = service1.listAll();
		model.addAttribute("listUsers", listUsers);
		
		List<Cake> listCakes = service2.listAll();
		model.addAttribute("listCakes", listCakes);
		
		return "index";
	}
	
	@RequestMapping("/new")
	public String showNewProductForm(Model model) {
		Product product = new Product();
		model.addAttribute("product", product);
		
		return "new_product";
	}
	
	@RequestMapping("/newCake")
	public String showNewCakeForm(Model model) {
		Cake cake = new Cake();
		model.addAttribute("cake", cake);
		
		return "new_cake";
	}
	
	@RequestMapping("/newUser")
	public String showNewUserForm(Model model) {
		User user = new User();
		List<Role> listRoles = service1.listRoles();
		model.addAttribute("user", user);
		model.addAttribute("listRoles", listRoles);
		return "new_user";
	}
	

	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("product") Product product) {
		service.save(product);
		
		return "redirect:/";
	}
	
	@RequestMapping(value = "/saveCake", method = RequestMethod.POST)
	public String saveCake(@ModelAttribute("cake") Cake cake) {
		service2.save(cake);
		
		return "redirect:/";
	}
	
	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("user") User user) {
		service1.save(user);
		
		return "redirect:/";
	}
	
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditProductForm(@PathVariable(name = "id") Long id) {
		ModelAndView mav = new ModelAndView("edit_product");
		
		Product product = service.get(id);
		mav.addObject("product", product);
		
		return mav;
	}
	
	@RequestMapping("/editCake/{id}")
	public ModelAndView showEditCakeForm(@PathVariable(name = "id") Long id) {
		ModelAndView mav = new ModelAndView("edit_cake");
		
		Cake cake = service2.get(id);
		mav.addObject("cake", cake);
		
		return mav;
	}
	
	@RequestMapping("/editUser/{id}")
	public ModelAndView showEditUserForm(@PathVariable(name = "id") Long id) {
		ModelAndView mav = new ModelAndView("edit_user");
		User user = service1.get(id);
		List<Role> listRoles = service1.listRoles();
		mav.addObject("user", user);
		mav.addObject("listRoles", listRoles);
		return mav;
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteProduct(@PathVariable(name = "id") Long id) {
		service.delete(id);
		
		return "redirect:/";
	}
	
	@RequestMapping("/deleteCake/{id}")
	public String deleteCake(@PathVariable(name = "id") Long id) {
		service2.delete(id);
		
		return "redirect:/";
	}
	
	@RequestMapping("/deleteUser/{id}")
	public String deleteUser(@PathVariable(name = "id") Long id) {
		service1.delete(id);
		
		return "redirect:/";
	}
}
