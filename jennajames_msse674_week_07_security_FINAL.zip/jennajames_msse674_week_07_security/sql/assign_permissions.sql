INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (1, 1); /* user patrick has role USER */
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (2, 2); /* user alex has role CREATOR */
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (3, 3); /* user john has role EDITOR */
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (4, 2); /* user jenna has role CREATOR */
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (4, 3); /* user jenna has role EDITOR */
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES (5, 4); /* user admin has role ADMIN */